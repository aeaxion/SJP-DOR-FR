"use client";
import { createContext, useCallback, useContext, useEffect, useMemo, useState, ReactNode } from "react";
import type { User } from "@supabase/supabase-js";
import { supabase, isConfigured } from "./supabase";
import type { Category, CategoryNominee, GalleryItem, HallEntry, Nominee, ResultRow, Settings } from "./types";

type Store = {
  loading: boolean;
  configured: boolean;
  error: string | null;
  user: User | null;
  isAdmin: boolean;
  settings: Settings | null;
  nominees: Nominee[];
  categories: Category[];
  ballots: CategoryNominee[];
  results: ResultRow[];
  myVotes: Record<string, string>;
  gallery: GalleryItem[];
  hall: HallEntry[];
  refresh: () => Promise<void>;
  nomineesFor: (categoryId: string) => Nominee[];
  tally: (categoryId: string) => { nominee: Nominee; votes: number; pct: number; rank: number }[];
  total: (categoryId: string) => number;
  resultsVisible: (c: Category) => boolean;
};

const Ctx = createContext<Store | null>(null);
export const useStore = () => {
  const v = useContext(Ctx);
  if (!v) throw new Error("useStore outside provider");
  return v;
};

export function StoreProvider({ children }: { children: ReactNode }) {
  const configured = isConfigured();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [user, setUser] = useState<User | null>(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [settings, setSettings] = useState<Settings | null>(null);
  const [nominees, setNominees] = useState<Nominee[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [ballots, setBallots] = useState<CategoryNominee[]>([]);
  const [results, setResults] = useState<ResultRow[]>([]);
  const [myVotes, setMyVotes] = useState<Record<string, string>>({});
  const [gallery, setGallery] = useState<GalleryItem[]>([]);
  const [hall, setHall] = useState<HallEntry[]>([]);

  const refresh = useCallback(async () => {
    if (!configured) { setLoading(false); return; }
    const sb = supabase();
    try {
      const { data: auth } = await sb.auth.getUser();
      setUser(auth.user);
      const [s, n, c, b, r, g, h] = await Promise.all([
        sb.from("settings").select("*").eq("id", 1).single(),
        sb.from("nominees").select("*").order("sort_order"),
        sb.from("categories").select("*").order("sort_order"),
        sb.from("category_nominees").select("*"),
        sb.rpc("get_results"),
        sb.from("gallery").select("*").order("created_at", { ascending: false }),
        sb.from("hall_of_fame").select("*").order("edition_year", { ascending: false }),
      ]);
      const firstErr = [s, n, c, b, r, g, h].find((x) => x.error)?.error;
      if (firstErr) throw firstErr;
      setSettings(s.data as Settings);
      setNominees((n.data ?? []) as Nominee[]);
      setCategories((c.data ?? []) as Category[]);
      setBallots((b.data ?? []) as CategoryNominee[]);
      setResults(((r.data ?? []) as ResultRow[]).map((x) => ({ ...x, votes: Number(x.votes) })));
      setGallery((g.data ?? []) as GalleryItem[]);
      setHall((h.data ?? []) as HallEntry[]);
      if (auth.user) {
        const [mv, me] = await Promise.all([
          sb.rpc("my_votes"),
          sb.from("profiles").select("is_admin").eq("id", auth.user.id).single(),
        ]);
        const map: Record<string, string> = {};
        ((mv.data ?? []) as { category_id: string; nominee_id: string }[]).forEach((v) => (map[v.category_id] = v.nominee_id));
        setMyVotes(map);
        setIsAdmin(!!me.data?.is_admin);
      } else {
        setMyVotes({});
        setIsAdmin(false);
      }
      setError(null);
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : (e as { message?: string })?.message || "Failed to load data");
    } finally {
      setLoading(false);
    }
  }, [configured]);

  useEffect(() => {
    refresh();
    if (!configured) return;
    const sb = supabase();
    const { data: sub } = sb.auth.onAuthStateChange(() => refresh());
    const ch = sb
      .channel("sjp-live")
      .on("postgres_changes", { event: "*", schema: "public", table: "votes" }, () => refresh())
      .on("postgres_changes", { event: "*", schema: "public", table: "settings" }, () => refresh())
      .on("postgres_changes", { event: "*", schema: "public", table: "categories" }, () => refresh())
      .subscribe();
    return () => { sub.subscription.unsubscribe(); sb.removeChannel(ch); };
  }, [configured, refresh]);

  const value = useMemo<Store>(() => {
    const nomineesFor = (cid: string) => {
      const ids = new Set(ballots.filter((x) => x.category_id === cid).map((x) => x.nominee_id));
      return nominees.filter((n) => ids.has(n.id));
    };
    const total = (cid: string) => results.filter((r) => r.category_id === cid).reduce((a, r) => a + r.votes, 0);
    const tally = (cid: string) => {
      const t = total(cid);
      const rows = nomineesFor(cid)
        .map((n) => {
          const v = results.find((r) => r.category_id === cid && r.nominee_id === n.id)?.votes ?? 0;
          return { nominee: n, votes: v, pct: t ? (v / t) * 100 : 0, rank: 0 };
        })
        .sort((a, b) => b.votes - a.votes || a.nominee.sort_order - b.nominee.sort_order);
      rows.forEach((r, i) => (r.rank = i + 1));
      return rows;
    };
    const resultsVisible = (c: Category) => isAdmin || !!settings?.show_live_results || c.revealed;
    return { loading, configured, error, user, isAdmin, settings, nominees, categories, ballots, results, myVotes, gallery, hall, refresh, nomineesFor, tally, total, resultsVisible };
  }, [loading, configured, error, user, isAdmin, settings, nominees, categories, ballots, results, myVotes, gallery, hall, refresh]);

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}
