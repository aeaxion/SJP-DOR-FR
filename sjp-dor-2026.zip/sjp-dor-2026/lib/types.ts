export type Settings = {
  voting_open: boolean;
  allow_vote_change: boolean;
  show_live_results: boolean;
  show_percentages_on_cards: boolean;
  event_date: string;
  nominations_date: string | null;
  voting_start_date: string | null;
  voting_end_date: string | null;
  announcement_date: string | null;
  edition_year: number;
};

export type Nominee = {
  id: string;
  name: string;
  slug: string;
  image_url: string | null;
  bio: string | null;
  achievements: string[];
  notable_moments: string[];
  awards: string[];
  sort_order: number;
};

export type Category = {
  id: string;
  title: string;
  description: string | null;
  is_ultimate: boolean;
  sort_order: number;
  voting_open: boolean;
  revealed: boolean;
};

export type CategoryNominee = { category_id: string; nominee_id: string };
export type ResultRow = { category_id: string; nominee_id: string; votes: number };
export type GalleryItem = { id: string; image_url: string; caption: string | null };
export type HallEntry = {
  id: string;
  edition_year: number;
  category_title: string;
  winner_name: string;
  image_url: string | null;
  note: string | null;
};
export type UserRow = {
  id: string;
  email: string;
  display_name: string;
  is_admin: boolean;
  is_banned: boolean;
  votes_cast: number;
  created_at: string;
};
