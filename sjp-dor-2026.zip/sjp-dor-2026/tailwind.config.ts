import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}", "./lib/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        ink: "#080808",
        charcoal: "#141414",
        gold: "#D4AF37",
        champagne: "#F5D76E",
        muted: "#A1A1A1",
      },
      fontFamily: {
        serif: ["var(--font-serif)", "Georgia", "serif"],
        sans: ["var(--font-sans)", "system-ui", "sans-serif"],
      },
      backgroundImage: {
        "gold-gradient": "linear-gradient(135deg, #8a6d1a 0%, #D4AF37 35%, #F5D76E 55%, #D4AF37 75%, #8a6d1a 100%)",
      },
      boxShadow: {
        gold: "0 0 40px rgba(212,175,55,0.25)",
        "gold-lg": "0 0 80px rgba(212,175,55,0.35)",
      },
      keyframes: {
        shimmer: { "0%": { backgroundPosition: "-200% 0" }, "100%": { backgroundPosition: "200% 0" } },
        float: { "0%,100%": { transform: "translateY(0)" }, "50%": { transform: "translateY(-14px)" } },
      },
      animation: { shimmer: "shimmer 4s linear infinite", float: "float 6s ease-in-out infinite" },
    },
  },
  plugins: [],
};
export default config;
