"use client";
import { useState } from "react";

export default function ShareButton({ text, label = "Share" }: { text: string; label?: string }) {
  const [done, setDone] = useState(false);
  const share = async () => {
    const url = typeof window !== "undefined" ? window.location.href : "";
    try {
      if (navigator.share) {
        await navigator.share({ title: "SJP DOR 2026", text, url });
        return;
      }
      await navigator.clipboard.writeText(`${text}\n${url}`);
      setDone(true);
      setTimeout(() => setDone(false), 2000);
    } catch {
      /* user cancelled */
    }
  };
  return (
    <button onClick={share} className="btn-ghost !px-5 !py-2.5">
      {done ? "Copied ✓" : label}
    </button>
  );
}
