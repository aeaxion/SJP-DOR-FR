"use client";
import { motion } from "framer-motion";
import Particles from "./Particles";

/**
 * Original SJP DOR trophy: a gold orb held by a sculpted stem on a tiered black base.
 * The orb has a slow "rotating" lat/long grid + shifting highlight for a 3D feel.
 */
export default function Trophy({ className = "" }: { className?: string }) {
  return (
    <div className={`relative mx-auto aspect-[3/4] w-full max-w-[420px] ${className}`}>
      <div className="absolute inset-0 -z-0 rounded-full bg-gold/20 blur-[90px]" />
      <Particles count={40} />
      <motion.div className="relative h-full w-full animate-float" initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 1.6 }}>
        <svg viewBox="0 0 300 400" className="h-full w-full drop-shadow-[0_0_40px_rgba(212,175,55,0.45)]">
          <defs>
            <radialGradient id="orb" cx="35%" cy="30%" r="75%">
              <stop offset="0%" stopColor="#FFF6C9" />
              <stop offset="25%" stopColor="#F5D76E" />
              <stop offset="60%" stopColor="#D4AF37" />
              <stop offset="100%" stopColor="#6b520f" />
            </radialGradient>
            <linearGradient id="metal" x1="0" x2="1">
              <stop offset="0%" stopColor="#6b520f" />
              <stop offset="30%" stopColor="#F5D76E" />
              <stop offset="55%" stopColor="#D4AF37" />
              <stop offset="100%" stopColor="#5a440c" />
            </linearGradient>
            <linearGradient id="base" x1="0" x2="1">
              <stop offset="0%" stopColor="#0c0c0c" />
              <stop offset="50%" stopColor="#262626" />
              <stop offset="100%" stopColor="#0c0c0c" />
            </linearGradient>
            <clipPath id="orbclip"><circle cx="150" cy="120" r="82" /></clipPath>
          </defs>

          {/* orb */}
          <circle cx="150" cy="120" r="82" fill="url(#orb)" />
          <g clipPath="url(#orbclip)" stroke="#8a6d1a" strokeOpacity="0.55" strokeWidth="1" fill="none">
            {/* rotating meridians */}
            {[0, 1, 2, 3, 4].map((i) => (
              <motion.ellipse
                key={i}
                cx="150" cy="120" ry="82"
                animate={{ rx: [82 * Math.abs(Math.cos((i * Math.PI) / 5)), 82 * Math.abs(Math.cos(((i + 5) * Math.PI) / 5))] }}
                transition={{ duration: 8, repeat: Infinity, ease: "linear", repeatType: "loop" }}
              />
            ))}
            {[-50, -25, 0, 25, 50].map((dy) => (
              <ellipse key={dy} cx="150" cy={120 + dy} rx={Math.sqrt(82 * 82 - dy * dy)} ry={8} />
            ))}
          </g>
          <ellipse cx="120" cy="82" rx="26" ry="14" fill="#fff" opacity="0.35" transform="rotate(-30 120 82)" />
          <motion.circle cx="150" cy="120" r="82" fill="none" stroke="#FFF6C9" strokeOpacity="0.5" strokeWidth="1.5"
            animate={{ opacity: [0.2, 0.7, 0.2] }} transition={{ duration: 3, repeat: Infinity }} />

          {/* neck + hands */}
          <path d="M118 196 C130 214 170 214 182 196 L176 222 C168 232 132 232 124 222 Z" fill="url(#metal)" />
          {/* stem */}
          <path d="M132 222 C140 250 138 276 126 300 L174 300 C162 276 160 250 168 222 Z" fill="url(#metal)" />
          <path d="M128 300 h44 l8 14 h-60 z" fill="url(#metal)" />
          {/* base tiers */}
          <rect x="88" y="314" width="124" height="22" rx="3" fill="url(#base)" stroke="#D4AF37" strokeOpacity="0.6" />
          <rect x="68" y="336" width="164" height="26" rx="3" fill="url(#base)" stroke="#D4AF37" strokeOpacity="0.6" />
          <rect x="50" y="362" width="200" height="22" rx="3" fill="url(#base)" stroke="#D4AF37" strokeOpacity="0.6" />
          <text x="150" y="351" textAnchor="middle" fontFamily="Georgia, serif" fontSize="11" letterSpacing="4" fill="#F5D76E">SJP DOR</text>
          <text x="150" y="377" textAnchor="middle" fontFamily="Georgia, serif" fontSize="10" letterSpacing="6" fill="#D4AF37">2026</text>
        </svg>
      </motion.div>
    </div>
  );
}
