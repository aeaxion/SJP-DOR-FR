"use client";
import { ReactNode } from "react";
import { motion } from "framer-motion";
import { usePathname } from "next/navigation";
import { StoreProvider, useStore } from "@/lib/store";
import Nav from "./Nav";
import Particles from "./Particles";

function Inner({ children }: { children: ReactNode }) {
  const path = usePathname();
  const { configured, error, loading } = useStore();
  return (
    <>
      <div className="fixed inset-0 -z-10"><Particles count={35} /></div>
      <Nav />
      {!configured && (
        <div className="border-b border-gold/30 bg-gold/10 px-5 py-3 text-center text-xs text-champagne">
          Supabase isn’t configured yet. Copy <code>.env.example</code> to <code>.env.local</code>, add your project URL and anon key, and run <code>supabase/schema.sql</code>.
        </div>
      )}
      {configured && error && (
        <div className="border-b border-red-500/40 bg-red-500/10 px-5 py-3 text-center text-xs text-red-300">
          Couldn’t load data: {error}. Did you run <code>supabase/schema.sql</code>?
        </div>
      )}
      <motion.main key={path} initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6, ease: "easeOut" }} className="min-h-[70vh]">
        {loading && configured ? <Loading /> : children}
      </motion.main>
      <footer className="mt-24 border-t border-gold/15 py-10 text-center">
        <p className="font-serif text-lg gold-text tracking-[0.2em]">FIVE NOMINEES. ONE CROWN. ETERNAL GLORY.</p>
        <p className="mt-2 text-[11px] uppercase tracking-[0.3em] text-muted">SJP DOR 2026 · An original awards ceremony</p>
      </footer>
    </>
  );
}

export function Loading() {
  return (
    <div className="flex h-[60vh] items-center justify-center">
      <div className="h-10 w-10 animate-spin rounded-full border-2 border-gold/20 border-t-gold" />
    </div>
  );
}

export default function Shell({ children }: { children: ReactNode }) {
  return (
    <StoreProvider>
      <Inner>{children}</Inner>
    </StoreProvider>
  );
}
