"use client";
import { useEffect, useState } from "react";

export default function Countdown({ target }: { target: string | null | undefined }) {
  const [now, setNow] = useState<number | null>(null);
  useEffect(() => {
    setNow(Date.now());
    const t = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(t);
  }, []);
  if (!target) return null;
  const diff = now === null ? 0 : Math.max(0, new Date(target).getTime() - now);
  const parts = [
    ["Days", Math.floor(diff / 86400000)],
    ["Hours", Math.floor(diff / 3600000) % 24],
    ["Minutes", Math.floor(diff / 60000) % 60],
    ["Seconds", Math.floor(diff / 1000) % 60],
  ] as const;
  const live = now !== null && diff === 0;
  return (
    <div>
      <p className="eyebrow mb-3 text-center">{live ? "The ceremony is underway" : "The ceremony begins in"}</p>
      <div className="flex justify-center gap-3 md:gap-5">
        {parts.map(([label, v]) => (
          <div key={label} className="glass min-w-[68px] px-3 py-3 text-center md:min-w-[92px] md:px-5 md:py-4">
            <div className="font-serif text-3xl tabular-nums gold-text md:text-5xl">{String(v).padStart(2, "0")}</div>
            <div className="mt-1 text-[9px] uppercase tracking-[0.25em] text-muted md:text-[10px]">{label}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
