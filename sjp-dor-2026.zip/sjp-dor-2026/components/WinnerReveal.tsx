"use client";
import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import Avatar from "./Avatar";
import Particles from "./Particles";
import ShareButton from "./ShareButton";
import type { Category, Nominee } from "@/lib/types";

type Row = { nominee: Nominee; votes: number; pct: number; rank: number };

/** Full-screen cinematic reveal. Stages: 0 dark → 1 category → 2 nominees → 3 spotlight winner → 4 vote count. */
export default function WinnerReveal({ category, rows, onClose }: { category: Category; rows: Row[]; onClose: () => void }) {
  const [stage, setStage] = useState(0);
  const winner = rows[0];
  const ultimate = category.is_ultimate;
  const tie = rows.length > 1 && rows[0].votes === rows[1].votes && rows[0].votes > 0;

  useEffect(() => {
    const t = ultimate ? [1200, 4200, 8200, 12500] : [900, 3200, 6200, 9200];
    const ids = t.map((ms, i) => setTimeout(() => setStage(i + 1), ms));
    return () => ids.forEach(clearTimeout);
  }, [ultimate]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => { window.removeEventListener("keydown", onKey); document.body.style.overflow = ""; };
  }, [onClose]);

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 1 }} className="fixed inset-0 z-[60] flex items-center justify-center overflow-hidden bg-black">
      {stage >= 1 && <Particles burst count={ultimate ? 90 : 60} />}
      {stage >= 3 && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 1.5 }}
          className="pointer-events-none absolute inset-0"
          style={{ background: "radial-gradient(ellipse 45% 65% at 50% 38%, rgba(245,215,110,0.38), rgba(212,175,55,0.1) 45%, transparent 70%)" }} />
      )}
      <button onClick={onClose} className="absolute right-5 top-5 z-10 text-[11px] uppercase tracking-[0.3em] text-muted hover:text-gold">Close ✕</button>

      <div className="relative z-10 w-full max-w-4xl px-5 text-center">
        <AnimatePresence mode="wait">
          {stage === 1 && (
            <motion.div key="cat" initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0 }} transition={{ duration: 1 }}>
              <p className="eyebrow mb-6">{ultimate ? "The Ultimate Award" : "And the award for"}</p>
              <h2 className="font-serif text-5xl gold-text md:text-8xl">{category.title}</h2>
            </motion.div>
          )}
          {stage === 2 && (
            <motion.div key="noms" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
              <p className="eyebrow mb-8">The nominees</p>
              <div className="flex flex-wrap justify-center gap-5 md:gap-8">
                {[...rows].sort((a, b) => a.nominee.sort_order - b.nominee.sort_order).map((r, i) => (
                  <motion.div key={r.nominee.id} initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.4 }} className="w-24 md:w-36">
                    <Avatar nominee={r.nominee} className="aspect-square w-full rounded-full border-2 border-gold/50" textClass="text-3xl" />
                    <p className="mt-3 font-serif text-lg tracking-[0.12em] text-champagne md:text-xl">{r.nominee.name}</p>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          )}
          {stage >= 3 && winner && (
            <motion.div key="win" initial={{ opacity: 0, scale: 0.8 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 1.6, ease: "easeOut" }}>
              <p className="eyebrow mb-5">{tie ? "Joint winners — a tie at the top" : ultimate ? "The winner of SJP DOR 2026" : "The winner is"}</p>
              <div className="relative mx-auto w-52 md:w-72">
                <div className="absolute -inset-6 rounded-full bg-gold/30 blur-3xl" />
                <Avatar nominee={winner.nominee} className="relative aspect-square w-full rounded-full border-4 border-champagne shadow-gold-lg" textClass="text-7xl" />
              </div>
              <h2 className="mt-8 font-serif text-6xl tracking-[0.12em] gold-text md:text-9xl">{winner.nominee.name}</h2>
              {tie && <p className="mt-2 text-muted">Shared with {rows.filter((r) => r.votes === winner.votes && r.nominee.id !== winner.nominee.id).map((r) => r.nominee.name).join(", ")}</p>}
              <p className="mt-3 text-xs uppercase tracking-[0.3em] text-muted">{category.title}</p>
              {stage >= 4 && (
                <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 1 }} className="mt-8">
                  <p className="font-serif text-5xl text-champagne md:text-6xl">{winner.votes}</p>
                  <p className="text-xs uppercase tracking-[0.3em] text-muted">Final votes · {winner.pct.toFixed(1)}%</p>
                  <div className="mt-8 flex justify-center gap-3">
                    <ShareButton text={`${winner.nominee.name} wins ${category.title} at SJP DOR 2026 with ${winner.votes} votes!`} label="Share winner" />
                    <button onClick={onClose} className="btn-gold !py-2.5">Continue</button>
                  </div>
                </motion.div>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.div>
  );
}
