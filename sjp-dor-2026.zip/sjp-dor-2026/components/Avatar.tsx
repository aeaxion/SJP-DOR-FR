import type { Nominee } from "@/lib/types";

/** Nominee photo, or a gold monogram when no picture has been uploaded yet. */
export default function Avatar({ nominee, className = "", textClass = "text-5xl" }: { nominee: Pick<Nominee, "name" | "image_url">; className?: string; textClass?: string }) {
  return (
    <div className={`relative overflow-hidden bg-gradient-to-br from-[#241d08] via-charcoal to-ink ${className}`}>
      {nominee.image_url ? (
        // eslint-disable-next-line @next/next/no-img-element
        <img src={nominee.image_url} alt={nominee.name} className="h-full w-full object-cover" />
      ) : (
        <div className="flex h-full w-full items-center justify-center">
          <span className={`font-serif gold-text ${textClass}`}>{nominee.name.slice(0, 2).toUpperCase()}</span>
        </div>
      )}
    </div>
  );
}
