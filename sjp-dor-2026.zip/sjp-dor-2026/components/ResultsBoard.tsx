"use client";
import { motion } from "framer-motion";
import Avatar from "./Avatar";
import ShareButton from "./ShareButton";
import { useStore } from "@/lib/store";
import type { Category } from "@/lib/types";

/** Animated ranked list with golden progress bars. Re-orders smoothly via layout animation. */
export default function ResultsBoard({ category }: { category: Category }) {
  const { tally, total, resultsVisible } = useStore();
  if (!resultsVisible(category)) {
    return (
      <div className="glass p-10 text-center">
        <p className="font-serif text-2xl gold-text">Results are sealed</p>
        <p className="mt-2 text-sm text-muted">The results stay hidden until voting closes.</p>
      </div>
    );
  }
  const rows = tally(category.id);
  const t = total(category.id);
  const shareText = `${category.title} — ${rows.slice(0, 3).map((r) => `${r.rank}. ${r.nominee.name} (${r.votes})`).join(", ")}`;
  return (
    <div>
      <div className="mb-6 flex items-center justify-between">
        <p className="text-xs uppercase tracking-[0.25em] text-muted">Total votes <span className="ml-2 font-serif text-2xl text-champagne">{t}</span></p>
        <ShareButton text={shareText} label="Share" />
      </div>
      <div className="space-y-3">
        {rows.map((r) => (
          <motion.div layout key={r.nominee.id} transition={{ type: "spring", stiffness: 260, damping: 28 }} className={`glass flex items-center gap-4 p-4 ${r.rank === 1 && r.votes > 0 ? "!border-gold shadow-gold" : ""}`}>
            <span className={`w-8 text-center font-serif text-3xl ${r.rank === 1 ? "gold-text" : "text-muted"}`}>{r.rank}</span>
            <Avatar nominee={r.nominee} className="h-14 w-14 shrink-0 rounded-full border border-gold/40" textClass="text-lg" />
            <div className="min-w-0 flex-1">
              <div className="mb-2 flex items-baseline justify-between gap-3">
                <span className="truncate font-serif text-xl tracking-[0.1em]">{r.nominee.name}</span>
                <span className="shrink-0 text-sm tabular-nums text-muted"><span className="text-champagne">{r.votes}</span> votes · {r.pct.toFixed(1)}%</span>
              </div>
              <div className="h-2.5 overflow-hidden rounded-full bg-white/10">
                <motion.div className="h-full rounded-full bg-gold-gradient" initial={{ width: 0 }} animate={{ width: `${r.pct}%` }} transition={{ duration: 1.1, ease: "easeOut" }} />
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
