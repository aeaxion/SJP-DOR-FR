"use client";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useState } from "react";
import { useStore } from "@/lib/store";
import { supabase } from "@/lib/supabase";

const links = [
  ["/nominees", "Nominees"],
  ["/vote", "Vote"],
  ["/results", "Results"],
  ["/leaderboard", "Leaderboard"],
  ["/verdict", "Final Verdict"],
  ["/hall-of-fame", "Hall of Fame"],
  ["/gallery", "Gallery"],
  ["/timeline", "Timeline"],
];

export default function Nav() {
  const path = usePathname();
  const router = useRouter();
  const { user, isAdmin, configured } = useStore();
  const [open, setOpen] = useState(false);

  const signOut = async () => {
    await supabase().auth.signOut();
    setOpen(false);
    router.push("/");
  };

  return (
    <header className="sticky top-0 z-40 border-b border-gold/15 bg-ink/75 backdrop-blur-xl">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-5">
        <Link href="/" className="font-serif text-xl tracking-[0.18em] gold-text">SJP DOR <span className="text-champagne/80">26</span></Link>
        <nav className="hidden items-center gap-6 lg:flex">
          {links.map(([href, label]) => (
            <Link key={href} href={href} className={`text-[11px] uppercase tracking-[0.2em] transition-colors hover:text-champagne ${path.startsWith(href) ? "text-champagne" : "text-muted"}`}>
              {label}
            </Link>
          ))}
        </nav>
        <div className="hidden items-center gap-3 lg:flex">
          {isAdmin && <Link href="/admin" className="text-[11px] uppercase tracking-[0.2em] text-gold">Admin</Link>}
          {configured && (user ? (
            <button onClick={signOut} className="btn-ghost !px-4 !py-2">Sign out</button>
          ) : (
            <Link href="/login" className="btn-gold !px-5 !py-2">Sign in</Link>
          ))}
        </div>
        <button className="lg:hidden text-gold" aria-label="Menu" onClick={() => setOpen(!open)}>
          <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6"><path d={open ? "M6 6l12 12M18 6L6 18" : "M4 7h16M4 12h16M4 17h16"} /></svg>
        </button>
      </div>
      {open && (
        <div className="border-t border-gold/15 bg-ink/95 px-5 py-4 lg:hidden">
          <div className="grid gap-1">
            {links.map(([href, label]) => (
              <Link key={href} href={href} onClick={() => setOpen(false)} className="py-2.5 text-sm uppercase tracking-[0.2em] text-muted hover:text-champagne">{label}</Link>
            ))}
            {isAdmin && <Link href="/admin" onClick={() => setOpen(false)} className="py-2.5 text-sm uppercase tracking-[0.2em] text-gold">Admin</Link>}
            {configured && (user
              ? <button onClick={signOut} className="py-2.5 text-left text-sm uppercase tracking-[0.2em] text-muted">Sign out</button>
              : <Link href="/login" onClick={() => setOpen(false)} className="py-2.5 text-sm uppercase tracking-[0.2em] text-gold">Sign in</Link>)}
          </div>
        </div>
      )}
    </header>
  );
}
