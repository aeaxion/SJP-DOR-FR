# SJP DOR 2026

Black-and-gold awards ceremony site: nominees, secure voting, live results, podium leaderboard, cinematic winner reveals, admin control room.

**Stack:** Next.js 14 (App Router) · Tailwind CSS · Framer Motion · Supabase (Postgres, Auth, Storage, Realtime)

## Setup (about 10 minutes)

1. **Create a Supabase project** at supabase.com.
2. **Run the schema:** open *SQL Editor*, paste all of `supabase/schema.sql`, run it. This creates tables, security rules, the vote function, storage buckets, and seeds the 5 nominees (VAR, AEAXION, BANGA, KEN, AK) and 12 categories.
3. **Add your keys:** copy `.env.example` to `.env.local` and fill in *Project Settings → API* values.
4. **Install and run:**
   ```bash
   npm install
   npm run dev
   ```
   Open http://localhost:3000.
5. **Make yourself admin:** sign up on the site, then in the SQL Editor run:
   ```sql
   update public.profiles set is_admin = true where email = 'you@example.com';
   ```
   An **Admin** link appears in the nav. Further admins can be promoted from the Users tab.
6. *(Optional, recommended for friend groups)* In Supabase *Authentication → Providers → Email*, turn off "Confirm email" so friends can vote right after signing up.

## Running the event

In **Admin → Controls**: set the ceremony date, then flip **Voting open**. Keep **Show live results** off to hide standings until you're ready. On the night, use **Admin → Reveal** to unveil winners one by one; anyone with **The Final Verdict** open gets the cinematic reveal automatically. Do the Ultimate Award last.

## How security works

- Votes live in the `votes` table with `unique (user_id, category_id)`, so duplicates are impossible at the database level.
- The browser has **no direct access** to `votes`. All voting goes through the `cast_vote` database function, which checks sign-in, ban status, voting open/closed, the category and ballot, and whether vote changes are allowed.
- `get_results` only returns counts when the admin has enabled live results, or the category is revealed (admins always see them). Hidden results are enforced in the database, not the UI.
- Every admin write (nominees, categories, settings, uploads, user flags, resets) is guarded by row-level security / `is_admin()` checks. Users cannot promote themselves.

## Pages

`/` home · `/nominees` + `/nominees/[slug]` · `/compare` · `/vote` · `/results` · `/leaderboard` · `/verdict` · `/hall-of-fame` · `/gallery` · `/timeline` · `/login` · `/admin`

## Notes

- Nominee photos are uploaded from **Admin → Nominees**. Until then, gold monograms are shown.
- New nominees must be added to a category's ballot (Admin → Categories → Ballot) before they can get votes. New custom categories start with every nominee on the ballot.
- Fonts (Cormorant Garamond + Inter) load from Google Fonts at runtime.
