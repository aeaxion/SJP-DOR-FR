-- ============================================================
-- SJP DOR 2026 — Supabase schema
-- Run this whole file in the Supabase SQL editor.
-- After signing up your own account, run at the bottom:
--   update public.profiles set is_admin = true where email = 'you@example.com';
-- ============================================================

create extension if not exists "pgcrypto";

-- ---------- Profiles (one per auth user) ----------
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  display_name text,
  is_admin boolean not null default false,
  is_banned boolean not null default false,
  created_at timestamptz not null default now()
);

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, email, display_name)
  values (new.id, new.email, coalesce(new.raw_user_meta_data->>'display_name', split_part(new.email, '@', 1)));
  return new;
end $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path = public as $$
  select coalesce((select is_admin from public.profiles where id = auth.uid()), false);
$$;

-- ---------- Settings (single row) ----------
create table if not exists public.settings (
  id int primary key default 1 check (id = 1),
  voting_open boolean not null default false,
  allow_vote_change boolean not null default false,
  show_live_results boolean not null default false,
  show_percentages_on_cards boolean not null default false,
  event_date timestamptz not null default (now() + interval '30 days'),
  nominations_date timestamptz,
  voting_start_date timestamptz,
  voting_end_date timestamptz,
  announcement_date timestamptz,
  edition_year int not null default 2026
);
insert into public.settings (id) values (1) on conflict do nothing;

-- ---------- Nominees ----------
create table if not exists public.nominees (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text unique not null,
  image_url text,
  bio text default '',
  achievements text[] not null default '{}',
  notable_moments text[] not null default '{}',
  awards text[] not null default '{}',
  sort_order int not null default 0,
  created_at timestamptz not null default now()
);

-- ---------- Categories ----------
create table if not exists public.categories (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text default '',
  is_ultimate boolean not null default false,
  sort_order int not null default 0,
  voting_open boolean not null default true,      -- per-category switch (also needs global voting_open)
  revealed boolean not null default false,        -- winner revealed on THE FINAL VERDICT
  created_at timestamptz not null default now()
);

-- Which nominees are on which category's ballot
create table if not exists public.category_nominees (
  category_id uuid not null references public.categories(id) on delete cascade,
  nominee_id uuid not null references public.nominees(id) on delete cascade,
  primary key (category_id, nominee_id)
);

-- ---------- Votes ----------
-- One vote per user per category enforced by the unique constraint.
create table if not exists public.votes (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  category_id uuid not null references public.categories(id) on delete cascade,
  nominee_id uuid not null references public.nominees(id) on delete cascade,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint one_vote_per_user_per_category unique (user_id, category_id),
  foreign key (category_id, nominee_id) references public.category_nominees(category_id, nominee_id) on delete cascade
);
create index if not exists votes_category_idx on public.votes(category_id, nominee_id);

-- ---------- Gallery, Hall of Fame ----------
create table if not exists public.gallery (
  id uuid primary key default gen_random_uuid(),
  image_url text not null,
  caption text default '',
  created_at timestamptz not null default now()
);

create table if not exists public.hall_of_fame (
  id uuid primary key default gen_random_uuid(),
  edition_year int not null,
  category_title text not null,
  winner_name text not null,
  image_url text,
  note text default '',
  created_at timestamptz not null default now()
);

-- ============================================================
-- Voting RPC — ALL vote validation happens here, on the server
-- ============================================================
create or replace function public.cast_vote(p_category uuid, p_nominee uuid)
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  uid uuid := auth.uid();
  s public.settings;
  c public.categories;
  existing public.votes;
begin
  if uid is null then raise exception 'You must be signed in to vote.'; end if;
  if exists (select 1 from public.profiles where id = uid and is_banned) then
    raise exception 'This account is not allowed to vote.';
  end if;

  select * into s from public.settings where id = 1;
  select * into c from public.categories where id = p_category;
  if c.id is null then raise exception 'Category not found.'; end if;
  if not s.voting_open or not c.voting_open then raise exception 'Voting is closed for this category.'; end if;
  if c.revealed then raise exception 'This award has already been revealed.'; end if;
  if not exists (select 1 from public.category_nominees where category_id = p_category and nominee_id = p_nominee) then
    raise exception 'That nominee is not on this ballot.';
  end if;

  select * into existing from public.votes where user_id = uid and category_id = p_category;
  if existing.id is not null then
    if not s.allow_vote_change then raise exception 'You have already voted in this category.'; end if;
    update public.votes set nominee_id = p_nominee, updated_at = now() where id = existing.id;
    return jsonb_build_object('status', 'changed');
  end if;

  insert into public.votes (user_id, category_id, nominee_id) values (uid, p_category, p_nominee);
  return jsonb_build_object('status', 'cast');
end $$;

revoke all on function public.cast_vote(uuid, uuid) from public;
grant execute on function public.cast_vote(uuid, uuid) to authenticated;

-- ============================================================
-- Results RPC — respects the admin "hide results" switch
-- Admins always see results. Everyone else only when allowed
-- (live results on, OR the category has been revealed).
-- ============================================================
create or replace function public.get_results()
returns table (category_id uuid, nominee_id uuid, votes bigint)
language plpgsql stable security definer set search_path = public as $$
declare s public.settings;
begin
  select * into s from public.settings where id = 1;
  return query
    select cn.category_id, cn.nominee_id, count(v.id)::bigint
    from public.category_nominees cn
    join public.categories c on c.id = cn.category_id
    left join public.votes v on v.category_id = cn.category_id and v.nominee_id = cn.nominee_id
    where public.is_admin() or s.show_live_results or c.revealed
    group by cn.category_id, cn.nominee_id;
end $$;
grant execute on function public.get_results() to anon, authenticated;

-- Which categories has the current user already voted in (and for whom)?
create or replace function public.my_votes()
returns table (category_id uuid, nominee_id uuid)
language sql stable security definer set search_path = public as $$
  select category_id, nominee_id from public.votes where user_id = auth.uid();
$$;
grant execute on function public.my_votes() to authenticated;

-- ============================================================
-- Admin RPCs
-- ============================================================
create or replace function public.admin_reset_votes(p_category uuid default null)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'Not authorized.'; end if;
  if p_category is null then delete from public.votes where true;
  else delete from public.votes where category_id = p_category; end if;
  update public.categories set revealed = false where p_category is null or id = p_category;
end $$;
grant execute on function public.admin_reset_votes(uuid) to authenticated;

create or replace function public.admin_user_stats()
returns table (id uuid, email text, display_name text, is_admin boolean, is_banned boolean, votes_cast bigint, created_at timestamptz)
language plpgsql stable security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'Not authorized.'; end if;
  return query
    select p.id, p.email, p.display_name, p.is_admin, p.is_banned,
           (select count(*) from public.votes v where v.user_id = p.id)::bigint, p.created_at
    from public.profiles p order by p.created_at;
end $$;
grant execute on function public.admin_user_stats() to authenticated;

create or replace function public.admin_set_user_flags(p_user uuid, p_banned boolean, p_admin boolean)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'Not authorized.'; end if;
  update public.profiles set is_banned = p_banned, is_admin = p_admin where id = p_user;
end $$;
grant execute on function public.admin_set_user_flags(uuid, boolean, boolean) to authenticated;

-- ============================================================
-- Row Level Security
-- ============================================================
alter table public.profiles enable row level security;
alter table public.settings enable row level security;
alter table public.nominees enable row level security;
alter table public.categories enable row level security;
alter table public.category_nominees enable row level security;
alter table public.votes enable row level security;
alter table public.gallery enable row level security;
alter table public.hall_of_fame enable row level security;

-- Profiles: read own row; admins read all. Users can NOT change is_admin / is_banned.
create policy "profile self read" on public.profiles for select using (id = auth.uid() or public.is_admin());
create policy "profile self update name" on public.profiles for update
  using (id = auth.uid()) with check (id = auth.uid() and is_admin = (select p.is_admin from public.profiles p where p.id = auth.uid())
                                      and is_banned = (select p.is_banned from public.profiles p where p.id = auth.uid()));

-- Public read, admin write for content tables
do $$
declare t text;
begin
  foreach t in array array['settings','nominees','categories','category_nominees','gallery','hall_of_fame'] loop
    execute format('create policy "%1$s public read" on public.%1$s for select using (true)', t);
    execute format('create policy "%1$s admin insert" on public.%1$s for insert with check (public.is_admin())', t);
    execute format('create policy "%1$s admin update" on public.%1$s for update using (public.is_admin()) with check (public.is_admin())', t);
    execute format('create policy "%1$s admin delete" on public.%1$s for delete using (public.is_admin())', t);
  end loop;
end $$;

-- Votes: no direct client access at all. Everything goes through RPCs.
-- (RLS is enabled with no policies => denied.)

-- ============================================================
-- Realtime (live results refresh)
-- ============================================================
alter publication supabase_realtime add table public.votes;
alter publication supabase_realtime add table public.settings;
alter publication supabase_realtime add table public.categories;

-- ============================================================
-- Storage buckets (public read, admin write)
-- ============================================================
insert into storage.buckets (id, name, public) values ('nominees', 'nominees', true) on conflict do nothing;
insert into storage.buckets (id, name, public) values ('gallery', 'gallery', true) on conflict do nothing;

create policy "media public read" on storage.objects for select using (bucket_id in ('nominees','gallery'));
create policy "media admin insert" on storage.objects for insert with check (bucket_id in ('nominees','gallery') and public.is_admin());
create policy "media admin update" on storage.objects for update using (bucket_id in ('nominees','gallery') and public.is_admin());
create policy "media admin delete" on storage.objects for delete using (bucket_id in ('nominees','gallery') and public.is_admin());

-- ============================================================
-- Seed data: 5 nominees + 12 categories (all nominees on every ballot)
-- ============================================================
insert into public.nominees (name, slug, sort_order, bio) values
  ('VAR', 'var', 1, 'The final word on every dispute. Nothing gets past him — except the decisions he gets wrong.'),
  ('AEAXION', 'aeaxion', 2, 'A force of nature with a signature style all his own.'),
  ('BANGA', 'banga', 3, 'Big moments, bigger energy. When Banga turns up, everyone knows about it.'),
  ('KEN', 'ken', 4, 'Calm, calculated, and quietly lethal when it counts.'),
  ('AK', 'ak', 5, 'Unpredictable, unforgettable, and always in the highlight reel.')
on conflict (slug) do nothing;

insert into public.categories (title, is_ultimate, sort_order) values
  ('SJP DOR 2026 — The Ultimate Award', true, 1),
  ('Player of the Year', false, 2),
  ('Biggest Menace of the Year', false, 3),
  ('Funniest Member of the Year', false, 4),
  ('Most Clutch Member', false, 5),
  ('Biggest Carry of the Year', false, 6),
  ('Biggest Bottler of the Year', false, 7),
  ('Most Iconic Moments', false, 8),
  ('Best Personality', false, 9),
  ('Most Controversial Member', false, 10),
  ('Most Unexpected Performance', false, 11),
  ('Community Favourite', false, 12)
on conflict do nothing;

insert into public.category_nominees (category_id, nominee_id)
select c.id, n.id from public.categories c cross join public.nominees n
on conflict do nothing;
