"use client";
import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { useStore } from "@/lib/store";

export default function Gallery() {
  const { gallery } = useStore();
  const [open, setOpen] = useState<string | null>(null);
  const item = gallery.find((g) => g.id === open);
  return (
    <div className="mx-auto max-w-7xl px-5 py-16">
      <div className="mb-14 text-center">
        <p className="eyebrow mb-3">Moments that made the year</p>
        <h1 className="section-title">The SJP DOR Gallery</h1>
      </div>
      {gallery.length === 0 && <div className="glass p-12 text-center text-muted">No memories uploaded yet. The admin can add photos from the dashboard.</div>}
      <div className="columns-2 gap-4 md:columns-3 lg:columns-4">
        {gallery.map((g, i) => (
          <motion.button key={g.id} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: (i % 4) * 0.05 }}
            onClick={() => setOpen(g.id)} className="group relative mb-4 block w-full overflow-hidden rounded-xl border border-gold/25 transition-all hover:border-champagne hover:shadow-gold">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={g.image_url} alt={g.caption ?? "Gallery"} className="w-full transition-transform duration-700 group-hover:scale-105" loading="lazy" />
            {g.caption && <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/90 to-transparent p-3 text-left text-xs text-white opacity-0 transition-opacity group-hover:opacity-100">{g.caption}</div>}
          </motion.button>
        ))}
      </div>
      <AnimatePresence>
        {item && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setOpen(null)} className="fixed inset-0 z-50 flex cursor-zoom-out items-center justify-center bg-black/90 p-5">
            <div className="max-h-full max-w-4xl text-center">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={item.image_url} alt={item.caption ?? ""} className="max-h-[80vh] rounded-xl border border-gold/40 shadow-gold-lg" />
              {item.caption && <p className="mt-4 text-sm text-champagne">{item.caption}</p>}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
