"use client";
import { useState } from "react";
import Avatar from "@/components/Avatar";
import { useStore } from "@/lib/store";

export default function Compare() {
  const { nominees } = useStore();
  const [picked, setPicked] = useState<string[]>([]);
  const toggle = (id: string) => setPicked((p) => (p.includes(id) ? p.filter((x) => x !== id) : p.length >= 3 ? [...p.slice(1), id] : [...p, id]));
  const chosen = nominees.filter((n) => picked.includes(n.id));

  const rows: [string, (n: (typeof nominees)[number]) => React.ReactNode][] = [
    ["Biography", (n) => <p className="text-sm text-white/80">{n.bio || "—"}</p>],
    ["Achievements", (n) => <ul className="space-y-1.5 text-sm">{n.achievements.map((a, i) => <li key={i}>◆ {a}</li>)}{!n.achievements.length && "—"}</ul>],
    ["Notable moments", (n) => <ul className="space-y-1.5 text-sm">{n.notable_moments.map((a, i) => <li key={i}>◆ {a}</li>)}{!n.notable_moments.length && "—"}</ul>],
    ["Awards", (n) => <ul className="space-y-1.5 text-sm">{n.awards.map((a, i) => <li key={i}>◆ {a}</li>)}{!n.awards.length && "—"}</ul>],
    ["Totals", (n) => <p className="text-sm text-champagne">{n.achievements.length} achievements · {n.awards.length} awards</p>],
  ];

  return (
    <div className="mx-auto max-w-6xl px-5 py-16">
      <div className="mb-10 text-center">
        <p className="eyebrow mb-3">Head to head</p>
        <h1 className="section-title">Compare Nominees</h1>
        <p className="mt-4 text-sm text-muted">Pick up to three.</p>
      </div>
      <div className="mb-12 flex flex-wrap justify-center gap-4">
        {nominees.map((n) => (
          <button key={n.id} onClick={() => toggle(n.id)} className={`flex w-24 flex-col items-center gap-2 rounded-xl border p-3 transition-all ${picked.includes(n.id) ? "border-champagne bg-gold/10 shadow-gold" : "border-gold/20 hover:border-gold/60"}`}>
            <Avatar nominee={n} className="h-14 w-14 rounded-full" textClass="text-lg" />
            <span className="font-serif text-sm tracking-[0.1em]">{n.name}</span>
          </button>
        ))}
      </div>
      {chosen.length < 2 ? <p className="text-center text-muted">Select at least two nominees to compare.</p> : (
        <div className="overflow-x-auto">
          <table className="w-full min-w-[640px] border-separate border-spacing-3">
            <thead>
              <tr><th className="w-32" />{chosen.map((n) => (
                <th key={n.id} className="glass p-4"><Avatar nominee={n} className="mx-auto h-20 w-20 rounded-full border border-gold/40" textClass="text-2xl" /><div className="mt-2 font-serif text-2xl tracking-[0.12em] gold-text">{n.name}</div></th>
              ))}</tr>
            </thead>
            <tbody>
              {rows.map(([label, render]) => (
                <tr key={label}>
                  <td className="align-top text-[11px] uppercase tracking-[0.25em] text-gold">{label}</td>
                  {chosen.map((n) => <td key={n.id} className="glass align-top p-4">{render(n)}</td>)}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
