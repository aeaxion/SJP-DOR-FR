"use client";
import Link from "next/link";
import { motion } from "framer-motion";
import Avatar from "@/components/Avatar";
import { useStore } from "@/lib/store";

export default function Nominees() {
  const { nominees, categories, settings, tally, resultsVisible } = useStore();
  const ultimate = categories.find((c) => c.is_ultimate);
  const showPct = !!settings?.show_percentages_on_cards && !!ultimate && resultsVisible(ultimate);
  const pctMap = new Map(ultimate ? tally(ultimate.id).map((t) => [t.nominee.id, t.pct]) : []);

  return (
    <div className="mx-auto max-w-7xl px-5 py-16">
      <div className="mb-14 text-center">
        <p className="eyebrow mb-3">The Official Nominees</p>
        <h1 className="section-title">Meet the Legends</h1>
        <div className="mt-8"><Link href="/compare" className="btn-ghost">Compare nominees</Link></div>
      </div>
      <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
        {nominees.map((n, i) => (
          <motion.div key={n.id} initial={{ opacity: 0, y: 40 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: (i % 3) * 0.1 }}>
            <Link href={`/nominees/${n.slug}`} className="group relative block overflow-hidden rounded-2xl border border-gold/30 bg-charcoal transition-all duration-500 hover:-translate-y-2 hover:border-champagne hover:shadow-gold-lg">
              <div className="relative">
                <Avatar nominee={n} className="aspect-[4/5] w-full transition-transform duration-700 group-hover:scale-105" textClass="text-8xl" />
                <div className="absolute inset-0 bg-gradient-to-t from-charcoal via-transparent to-transparent" />
                <span className="absolute left-4 top-4 rounded-full border border-gold/50 bg-ink/70 px-3 py-1 text-[10px] uppercase tracking-[0.25em] text-gold backdrop-blur">Nominee {String(i + 1).padStart(2, "0")}</span>
                {showPct && <span className="absolute right-4 top-4 rounded-full bg-gold px-3 py-1 text-xs font-bold text-ink">{(pctMap.get(n.id) ?? 0).toFixed(0)}%</span>}
              </div>
              <div className="p-6">
                <h2 className="font-serif text-4xl tracking-[0.12em] gold-text">{n.name}</h2>
                <p className="mt-3 line-clamp-3 text-sm text-muted">{n.bio || "Profile coming soon."}</p>
                <div className="mt-5 flex gap-6 text-center text-[10px] uppercase tracking-[0.2em] text-muted">
                  <div><div className="font-serif text-2xl text-champagne">{n.achievements.length}</div>Achievements</div>
                  <div><div className="font-serif text-2xl text-champagne">{n.notable_moments.length}</div>Moments</div>
                  <div><div className="font-serif text-2xl text-champagne">{n.awards.length}</div>Awards</div>
                </div>
                <p className="mt-5 text-[11px] uppercase tracking-[0.3em] text-gold transition-transform group-hover:translate-x-2">View profile →</p>
              </div>
            </Link>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
