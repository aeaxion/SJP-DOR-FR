"use client";
import Link from "next/link";
import { useParams } from "next/navigation";
import { motion } from "framer-motion";
import Avatar from "@/components/Avatar";
import ShareButton from "@/components/ShareButton";
import { useStore } from "@/lib/store";

function List({ title, items }: { title: string; items: string[] }) {
  return (
    <div className="glass p-6">
      <h3 className="mb-4 font-serif text-2xl gold-text">{title}</h3>
      {items.length === 0 ? <p className="text-sm text-muted">Nothing listed yet.</p> : (
        <ul className="space-y-3">
          {items.map((a, i) => (
            <li key={i} className="flex gap-3 text-sm text-white/90"><span className="mt-1.5 h-1.5 w-1.5 shrink-0 rotate-45 bg-gold" />{a}</li>
          ))}
        </ul>
      )}
    </div>
  );
}

export default function Profile() {
  const { slug } = useParams<{ slug: string }>();
  const { nominees, categories, settings, tally, resultsVisible } = useStore();
  const n = nominees.find((x) => x.slug === slug);
  if (!n) return <div className="px-5 py-32 text-center text-muted">Nominee not found. <Link href="/nominees" className="text-gold underline">Back to nominees</Link></div>;

  const ultimate = categories.find((c) => c.is_ultimate);
  const row = ultimate && settings?.show_percentages_on_cards && resultsVisible(ultimate) ? tally(ultimate.id).find((t) => t.nominee.id === n.id) : null;

  return (
    <div className="mx-auto max-w-6xl px-5 py-14">
      <Link href="/nominees" className="text-[11px] uppercase tracking-[0.3em] text-muted hover:text-gold">← All nominees</Link>
      <div className="mt-8 grid gap-10 md:grid-cols-[380px_1fr]">
        <motion.div initial={{ opacity: 0, scale: 0.94 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 0.8 }}>
          <div className="overflow-hidden rounded-2xl border border-gold/40 shadow-gold-lg">
            <Avatar nominee={n} className="aspect-[4/5] w-full" textClass="text-9xl" />
          </div>
        </motion.div>
        <div>
          <p className="eyebrow mb-3">SJP DOR 2026 Nominee</p>
          <h1 className="font-serif text-6xl tracking-[0.12em] gold-text md:text-8xl">{n.name}</h1>
          <p className="mt-6 max-w-2xl text-lg leading-relaxed text-white/80">{n.bio || "Biography coming soon."}</p>
          {row && (
            <div className="mt-8 max-w-sm">
              <div className="mb-2 flex justify-between text-xs uppercase tracking-[0.2em] text-muted"><span>Ultimate Award</span><span className="text-champagne">{row.pct.toFixed(1)}%</span></div>
              <div className="h-2 overflow-hidden rounded-full bg-white/10"><motion.div className="h-full bg-gold-gradient" initial={{ width: 0 }} animate={{ width: `${row.pct}%` }} transition={{ duration: 1.2 }} /></div>
            </div>
          )}
          <div className="mt-8 flex flex-wrap gap-3">
            <Link href="/vote" className="btn-gold">Vote for {n.name}</Link>
            <ShareButton text={`Check out ${n.name} — nominee at SJP DOR 2026!`} />
          </div>
        </div>
      </div>
      <div className="mt-14 grid gap-6 md:grid-cols-3">
        <List title="Achievements" items={n.achievements} />
        <List title="Notable Moments" items={n.notable_moments} />
        <List title="Awards & Nominations" items={n.awards} />
      </div>
    </div>
  );
}
