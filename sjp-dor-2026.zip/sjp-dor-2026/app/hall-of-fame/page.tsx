"use client";
import Avatar from "@/components/Avatar";
import { useStore } from "@/lib/store";

export default function HallOfFame() {
  const { hall, categories, tally, settings } = useStore();
  const year = settings?.edition_year ?? 2026;
  // Current-edition winners (revealed) are shown alongside archived past editions.
  const current = categories.filter((c) => c.revealed).map((c) => { const w = tally(c.id)[0]; return w ? { id: c.id, edition_year: year, category_title: c.title, winner_name: w.nominee.name, image_url: w.nominee.image_url, note: `${w.votes} votes` } : null; }).filter(Boolean) as typeof hall;
  const all = [...current, ...hall];
  const years = Array.from(new Set(all.map((h) => h.edition_year))).sort((a, b) => b - a);

  return (
    <div className="mx-auto max-w-6xl px-5 py-16">
      <div className="mb-14 text-center">
        <p className="eyebrow mb-3">Immortalised</p>
        <h1 className="section-title">Hall of Fame</h1>
      </div>
      {years.length === 0 && <div className="glass p-12 text-center text-muted">No legends have been crowned yet. The first inductees will appear after the ceremony.</div>}
      {years.map((y) => (
        <section key={y} className="mb-14">
          <h2 className="mb-6 font-serif text-4xl gold-text">{y}</h2>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {all.filter((h) => h.edition_year === y).map((h) => (
              <div key={h.id} className="glass flex items-center gap-4 p-5 transition-all hover:border-champagne hover:shadow-gold">
                <Avatar nominee={{ name: h.winner_name, image_url: h.image_url }} className="h-16 w-16 shrink-0 rounded-full border border-gold/50" textClass="text-xl" />
                <div className="min-w-0">
                  <p className="text-[10px] uppercase tracking-[0.2em] text-gold">{h.category_title}</p>
                  <p className="font-serif text-2xl tracking-[0.1em]">{h.winner_name}</p>
                  {h.note && <p className="text-xs text-muted">{h.note}</p>}
                </div>
              </div>
            ))}
          </div>
        </section>
      ))}
    </div>
  );
}
