"use client";
import { FormEvent, useState } from "react";
import { useRouter } from "next/navigation";
import { supabase } from "@/lib/supabase";
import { useStore } from "@/lib/store";

export default function Login() {
  const router = useRouter();
  const { configured, refresh } = useStore();
  const [mode, setMode] = useState<"in" | "up">("in");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<{ type: "ok" | "err"; text: string } | null>(null);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (!configured) return setMsg({ type: "err", text: "Supabase isn’t configured yet." });
    setBusy(true); setMsg(null);
    const sb = supabase();
    if (mode === "up") {
      const { data, error } = await sb.auth.signUp({ email, password, options: { data: { display_name: name || email.split("@")[0] } } });
      if (error) setMsg({ type: "err", text: error.message });
      else if (!data.session) setMsg({ type: "ok", text: "Check your email to confirm your account, then sign in." });
      else { await refresh(); router.push("/vote"); }
    } else {
      const { error } = await sb.auth.signInWithPassword({ email, password });
      if (error) setMsg({ type: "err", text: error.message });
      else { await refresh(); router.push("/vote"); }
    }
    setBusy(false);
  };

  return (
    <div className="mx-auto max-w-md px-5 py-20">
      <div className="glass p-8 shadow-gold">
        <p className="eyebrow mb-2 text-center">Members only</p>
        <h1 className="mb-8 text-center font-serif text-4xl gold-text">{mode === "in" ? "Sign in" : "Create account"}</h1>
        <form onSubmit={submit} className="space-y-4">
          {mode === "up" && (
            <div><label className="label">Display name</label><input className="input" value={name} onChange={(e) => setName(e.target.value)} placeholder="Your name" /></div>
          )}
          <div><label className="label">Email</label><input className="input" type="email" required value={email} onChange={(e) => setEmail(e.target.value)} /></div>
          <div><label className="label">Password</label><input className="input" type="password" required minLength={6} value={password} onChange={(e) => setPassword(e.target.value)} /></div>
          {msg && <p className={`text-sm ${msg.type === "ok" ? "text-champagne" : "text-red-400"}`}>{msg.text}</p>}
          <button className="btn-gold w-full" disabled={busy}>{busy ? "Please wait…" : mode === "in" ? "Sign in" : "Create account"}</button>
        </form>
        <button onClick={() => { setMode(mode === "in" ? "up" : "in"); setMsg(null); }} className="mt-6 w-full text-center text-xs uppercase tracking-[0.2em] text-muted hover:text-gold">
          {mode === "in" ? "No account? Create one" : "Have an account? Sign in"}
        </button>
      </div>
    </div>
  );
}
