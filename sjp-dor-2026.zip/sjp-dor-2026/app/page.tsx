"use client";
import Link from "next/link";
import { motion } from "framer-motion";
import Trophy from "@/components/Trophy";
import Countdown from "@/components/Countdown";
import Avatar from "@/components/Avatar";
import { useStore } from "@/lib/store";

export default function Home() {
  const { settings, nominees } = useStore();
  return (
    <>
      <section className="relative mx-auto grid max-w-7xl items-center gap-10 px-5 pb-16 pt-14 md:grid-cols-2 md:pt-24">
        <div className="text-center md:text-left">
          <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.2 }} className="eyebrow mb-5">The {settings?.edition_year ?? 2026} Awards Ceremony</motion.p>
          <motion.h1 initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 1, delay: 0.3 }}
            className="font-serif text-[22vw] font-semibold leading-[0.85] gold-text animate-shimmer md:text-[9rem]">
            SJP DOR<br />2026
          </motion.h1>
          <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.9 }} className="mt-8 font-serif text-2xl tracking-[0.25em] text-champagne md:text-3xl">
            THE NIGHT OF LEGENDS.
          </motion.p>
          <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 1.1 }} className="mx-auto mt-4 max-w-md text-muted md:mx-0">
            One year. Five nominees. Countless moments. Only one ultimate winner.
          </motion.p>
          <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 1.3 }} className="mt-10 flex flex-col items-center gap-4 sm:flex-row md:justify-start justify-center">
            <Link href="/vote" className="btn-gold">Cast your vote</Link>
            <Link href="/nominees" className="btn-ghost">Meet the nominees</Link>
          </motion.div>
        </div>
        <Trophy />
      </section>

      <section className="mx-auto max-w-4xl px-5 py-10">
        <Countdown target={settings?.event_date} />
      </section>

      <section className="mx-auto max-w-7xl px-5 py-20">
        <div className="mb-12 text-center">
          <p className="eyebrow mb-3">The Shortlist</p>
          <h2 className="section-title">Five Nominees</h2>
        </div>
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-5">
          {nominees.map((n, i) => (
            <motion.div key={n.id} initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.08 }}>
              <Link href={`/nominees/${n.slug}`} className="group glass block overflow-hidden transition-all duration-500 hover:-translate-y-2 hover:shadow-gold-lg">
                <Avatar nominee={n} className="aspect-[4/5] w-full transition-transform duration-700 group-hover:scale-105" />
                <div className="border-t border-gold/20 p-4 text-center">
                  <p className="font-serif text-2xl tracking-[0.15em] gold-text">{n.name}</p>
                </div>
              </Link>
            </motion.div>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-5xl px-5 py-16 text-center">
        <div className="glass px-6 py-14 shadow-gold">
          <p className="eyebrow mb-4">Twelve Awards. One Crown.</p>
          <h2 className="section-title mb-6">Make your voice heard</h2>
          <p className="mx-auto mb-8 max-w-xl text-muted">From the Ultimate Award to Biggest Bottler of the Year — every category is decided by you. One vote per category. Sign in, choose wisely.</p>
          <Link href="/vote" className="btn-gold">Enter the voting hall</Link>
        </div>
      </section>
    </>
  );
}
