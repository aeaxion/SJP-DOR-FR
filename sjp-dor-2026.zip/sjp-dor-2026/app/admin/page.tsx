"use client";
import Link from "next/link";
import { ChangeEvent, ReactNode, useCallback, useEffect, useState } from "react";
import Avatar from "@/components/Avatar";
import { supabase } from "@/lib/supabase";
import { useStore } from "@/lib/store";
import type { Category, Nominee, Settings, UserRow } from "@/lib/types";

type Tab = "overview" | "controls" | "nominees" | "categories" | "reveal" | "users" | "media";
const TABS: [Tab, string][] = [
  ["overview", "Overview"], ["controls", "Controls"], ["nominees", "Nominees"], ["categories", "Categories"],
  ["reveal", "Reveal"], ["users", "Users"], ["media", "Gallery & Hall"],
];

const slugify = (s: string) => s.toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
const toLocal = (iso: string | null) => { if (!iso) return ""; const d = new Date(iso); d.setMinutes(d.getMinutes() - d.getTimezoneOffset()); return d.toISOString().slice(0, 16); };
const fromLocal = (v: string) => (v ? new Date(v).toISOString() : null);
const lines = (s: string) => s.split("\n").map((x) => x.trim()).filter(Boolean);

async function upload(bucket: "nominees" | "gallery", file: File) {
  const ext = file.name.split(".").pop() || "jpg";
  const path = `${crypto.randomUUID()}.${ext}`;
  const { error } = await supabase().storage.from(bucket).upload(path, file, { cacheControl: "3600", upsert: false });
  if (error) throw error;
  return supabase().storage.from(bucket).getPublicUrl(path).data.publicUrl;
}

function Toast({ msg }: { msg: { type: "ok" | "err"; text: string } | null }) {
  if (!msg) return null;
  return <div className={`fixed bottom-5 right-5 z-50 rounded-xl border px-5 py-3 text-sm shadow-gold ${msg.type === "ok" ? "border-gold bg-charcoal text-champagne" : "border-red-500/60 bg-charcoal text-red-300"}`}>{msg.text}</div>;
}

function Card({ title, children, action }: { title: string; children: ReactNode; action?: ReactNode }) {
  return (
    <div className="glass p-6">
      <div className="mb-4 flex items-center justify-between"><h3 className="font-serif text-2xl gold-text">{title}</h3>{action}</div>
      {children}
    </div>
  );
}

export default function Admin() {
  const { isAdmin, user, loading, configured, settings, nominees, categories, ballots, results, total, tally, hall, gallery, refresh } = useStore();
  const [tab, setTab] = useState<Tab>("overview");
  const [msg, setMsg] = useState<{ type: "ok" | "err"; text: string } | null>(null);
  const [busy, setBusy] = useState(false);

  const flash = (type: "ok" | "err", text: string) => { setMsg({ type, text }); setTimeout(() => setMsg(null), 3500); };
  // Runs an admin action; RLS / RPC checks on the server decide whether it is allowed.
  const run = async (fn: () => PromiseLike<{ error: { message: string } | null }> | Promise<void>, ok = "Saved") => {
    setBusy(true);
    try {
      const r = await fn();
      if (r && typeof r === "object" && "error" in r && r.error) throw new Error(r.error.message);
      flash("ok", ok);
      await refresh();
    } catch (e) {
      flash("err", e instanceof Error ? e.message : (e as { message?: string }).message || "Something went wrong");
    }
    setBusy(false);
  };

  if (!configured) return <div className="px-5 py-32 text-center text-muted">Configure Supabase first.</div>;
  if (loading) return null;
  if (!user) return <div className="px-5 py-32 text-center"><p className="mb-4 text-muted">Sign in to continue.</p><Link href="/login" className="btn-gold">Sign in</Link></div>;
  if (!isAdmin) return <div className="px-5 py-32 text-center"><p className="font-serif text-3xl gold-text">Access denied</p><p className="mt-2 text-muted">This area is for administrators only.</p></div>;

  return (
    <div className="mx-auto max-w-7xl px-5 py-12">
      <div className="mb-8"><p className="eyebrow mb-2">Administration</p><h1 className="section-title">Control Room</h1></div>
      <div className="mb-8 flex flex-wrap gap-2">
        {TABS.map(([k, label]) => (
          <button key={k} onClick={() => setTab(k)} className={`rounded-full border px-4 py-2 text-[11px] uppercase tracking-[0.15em] ${tab === k ? "border-gold bg-gold text-ink" : "border-gold/30 text-muted hover:text-champagne"}`}>{label}</button>
        ))}
      </div>

      {tab === "overview" && (
        <div className="grid gap-6 lg:grid-cols-2">
          <Card title="Totals">
            <div className="grid grid-cols-3 gap-4 text-center">
              {[["Votes", results.reduce((a, r) => a + r.votes, 0)], ["Categories", categories.length], ["Nominees", nominees.length]].map(([l, v]) => (
                <div key={l as string}><div className="font-serif text-4xl text-champagne">{v}</div><div className="text-[10px] uppercase tracking-[0.25em] text-muted">{l}</div></div>
              ))}
            </div>
          </Card>
          <Card title="Status">
            <ul className="space-y-2 text-sm">
              <li>Voting: <b className={settings?.voting_open ? "text-champagne" : "text-red-400"}>{settings?.voting_open ? "OPEN" : "CLOSED"}</b></li>
              <li>Vote changes: <b>{settings?.allow_vote_change ? "allowed" : "locked"}</b></li>
              <li>Public results: <b>{settings?.show_live_results ? "visible" : "hidden"}</b></li>
              <li>Revealed awards: <b>{categories.filter((c) => c.revealed).length}/{categories.length}</b></li>
            </ul>
          </Card>
          <div className="lg:col-span-2 grid gap-4 md:grid-cols-2">
            {categories.map((c) => (
              <Card key={c.id} title={c.title}>
                <p className="mb-3 text-xs text-muted">{total(c.id)} votes</p>
                {tally(c.id).map((r) => (
                  <div key={r.nominee.id} className="mb-2 flex items-center gap-3 text-sm"><span className="w-6 text-muted">{r.rank}</span><span className="flex-1">{r.nominee.name}</span><span className="tabular-nums text-champagne">{r.votes}</span><span className="w-14 text-right text-xs text-muted">{r.pct.toFixed(0)}%</span></div>
                ))}
              </Card>
            ))}
          </div>
        </div>
      )}

      {tab === "controls" && settings && <Controls s={settings} busy={busy} run={run} />}
      {tab === "nominees" && <NomineesAdmin nominees={nominees} busy={busy} run={run} flash={flash} />}
      {tab === "categories" && <CategoriesAdmin categories={categories} nominees={nominees} ballots={ballots} run={run} busy={busy} />}

      {tab === "reveal" && (
        <Card title="Reveal winners individually">
          <p className="mb-5 text-sm text-muted">Revealing an award publishes its results and triggers the cinematic ceremony for anyone watching <Link href="/verdict" className="text-gold underline">The Final Verdict</Link>. Reveal the Ultimate Award last.</p>
          <div className="space-y-3">
            {[...categories].sort((a, b) => Number(a.is_ultimate) - Number(b.is_ultimate)).map((c) => {
              const w = tally(c.id)[0];
              return (
                <div key={c.id} className="flex flex-wrap items-center gap-4 rounded-xl border border-gold/20 p-4">
                  <div className="min-w-0 flex-1"><p className="font-serif text-xl">{c.title}</p><p className="text-xs text-muted">Leader: {w && w.votes > 0 ? `${w.nominee.name} (${w.votes})` : "no votes"} · {total(c.id)} total</p></div>
                  <button disabled={busy} className={c.revealed ? "btn-ghost !py-2" : "btn-gold !py-2"}
                    onClick={() => run(() => supabase().from("categories").update({ revealed: !c.revealed }).eq("id", c.id), c.revealed ? "Hidden again" : "Winner revealed")}>
                    {c.revealed ? "Hide again" : "Reveal winner"}
                  </button>
                </div>
              );
            })}
          </div>
        </Card>
      )}

      {tab === "users" && <UsersAdmin run={run} busy={busy} me={user.id} />}
      {tab === "media" && <MediaAdmin gallery={gallery} hall={hall} year={settings?.edition_year ?? 2026} run={run} flash={flash} busy={busy} />}
      <Toast msg={msg} />
    </div>
  );
}

type Run = (fn: () => PromiseLike<{ error: { message: string } | null }> | Promise<void>, ok?: string) => Promise<void>;

/* ---------------- Controls ---------------- */
function Controls({ s, run, busy }: { s: Settings; run: Run; busy: boolean }) {
  const [f, setF] = useState({
    event_date: toLocal(s.event_date), nominations_date: toLocal(s.nominations_date), voting_start_date: toLocal(s.voting_start_date),
    voting_end_date: toLocal(s.voting_end_date), announcement_date: toLocal(s.announcement_date), edition_year: s.edition_year,
  });
  const set = (patch: Partial<Settings>, ok = "Updated") => run(() => supabase().from("settings").update(patch).eq("id", 1), ok);
  const Toggle = ({ k, label, hint }: { k: keyof Pick<Settings, "voting_open" | "allow_vote_change" | "show_live_results" | "show_percentages_on_cards">; label: string; hint: string }) => (
    <div className="flex items-center justify-between gap-4 border-b border-gold/10 py-4 last:border-0">
      <div><p className="text-sm">{label}</p><p className="text-xs text-muted">{hint}</p></div>
      <button disabled={busy} onClick={() => set({ [k]: !s[k] } as Partial<Settings>)} className={`relative h-7 w-14 shrink-0 rounded-full transition-colors ${s[k] ? "bg-gold" : "bg-white/15"}`} aria-pressed={s[k]}>
        <span className={`absolute top-1 h-5 w-5 rounded-full bg-ink transition-all ${s[k] ? "left-8" : "left-1"}`} />
      </button>
    </div>
  );
  return (
    <div className="grid gap-6 lg:grid-cols-2">
      <Card title="Switches">
        <Toggle k="voting_open" label="Voting open" hint="Master switch. Closed = nobody can cast or change a vote." />
        <Toggle k="allow_vote_change" label="Allow vote changes" hint="Let members change their pick while voting is open." />
        <Toggle k="show_live_results" label="Show live results" hint="Off = results stay hidden until you reveal each award." />
        <Toggle k="show_percentages_on_cards" label="Show % on nominee cards" hint="Needs results to be visible for the Ultimate Award." />
      </Card>
      <Card title="Dates">
        <div className="grid gap-3">
          {([["event_date", "Ceremony / countdown target"], ["nominations_date", "Nominations announced"], ["voting_start_date", "Voting begins"], ["voting_end_date", "Voting closes"], ["announcement_date", "Winner announcement"]] as const).map(([k, l]) => (
            <div key={k}><label className="label">{l}</label><input type="datetime-local" className="input" value={f[k]} onChange={(e) => setF({ ...f, [k]: e.target.value })} /></div>
          ))}
          <div><label className="label">Edition year</label><input type="number" className="input" value={f.edition_year} onChange={(e) => setF({ ...f, edition_year: Number(e.target.value) })} /></div>
          <button disabled={busy || !f.event_date} className="btn-gold" onClick={() => set({
            event_date: fromLocal(f.event_date) ?? s.event_date, nominations_date: fromLocal(f.nominations_date), voting_start_date: fromLocal(f.voting_start_date),
            voting_end_date: fromLocal(f.voting_end_date), announcement_date: fromLocal(f.announcement_date), edition_year: f.edition_year,
          }, "Dates saved")}>Save dates</button>
        </div>
      </Card>
      <div className="lg:col-span-2">
        <Card title="Danger zone">
          <p className="mb-4 text-sm text-muted">Deletes votes permanently and hides all revealed winners.</p>
          <button disabled={busy} className="rounded-full border border-red-500/60 px-6 py-3 text-xs uppercase tracking-[0.2em] text-red-300 hover:bg-red-500/10"
            onClick={() => { if (confirm("Reset ALL votes in ALL categories? This cannot be undone.")) run(() => supabase().rpc("admin_reset_votes", { p_category: null }), "All votes reset"); }}>
            Reset all voting
          </button>
        </Card>
      </div>
    </div>
  );
}

/* ---------------- Nominees ---------------- */
type NForm = { id?: string; name: string; slug: string; bio: string; achievements: string; notable_moments: string; awards: string; image_url: string | null; sort_order: number };
const emptyN = (n: number): NForm => ({ name: "", slug: "", bio: "", achievements: "", notable_moments: "", awards: "", image_url: null, sort_order: n });

function NomineesAdmin({ nominees, run, busy, flash }: { nominees: Nominee[]; run: Run; busy: boolean; flash: (t: "ok" | "err", s: string) => void }) {
  const [f, setF] = useState<NForm | null>(null);
  const edit = (n: Nominee) => setF({ id: n.id, name: n.name, slug: n.slug, bio: n.bio ?? "", achievements: n.achievements.join("\n"), notable_moments: n.notable_moments.join("\n"), awards: n.awards.join("\n"), image_url: n.image_url, sort_order: n.sort_order });
  const onFile = async (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]; if (!file || !f) return;
    try { const url = await upload("nominees", file); setF({ ...f, image_url: url }); flash("ok", "Image uploaded — remember to save"); } catch (err) { flash("err", (err as Error).message); }
  };
  const save = () => {
    if (!f || !f.name.trim()) return;
    const row = { name: f.name.trim(), slug: f.slug || slugify(f.name), bio: f.bio, achievements: lines(f.achievements), notable_moments: lines(f.notable_moments), awards: lines(f.awards), image_url: f.image_url, sort_order: f.sort_order };
    run(async () => {
      const q = f.id ? supabase().from("nominees").update(row).eq("id", f.id) : supabase().from("nominees").insert(row);
      const { error } = await q;
      if (error) throw error;
      setF(null);
    }, "Nominee saved");
  };
  const addAndBallot = () => setF(emptyN(nominees.length + 1));
  return (
    <div className="grid gap-6 lg:grid-cols-[1fr_420px]">
      <Card title="Nominees" action={<button className="btn-gold !px-5 !py-2" onClick={addAndBallot}>+ Add</button>}>
        <div className="space-y-3">
          {nominees.map((n) => (
            <div key={n.id} className="flex items-center gap-4 rounded-xl border border-gold/15 p-3">
              <Avatar nominee={n} className="h-14 w-14 shrink-0 rounded-full" textClass="text-lg" />
              <div className="min-w-0 flex-1"><p className="font-serif text-xl tracking-[0.1em]">{n.name}</p><p className="truncate text-xs text-muted">/{n.slug}</p></div>
              <button className="btn-ghost !px-4 !py-2" onClick={() => edit(n)}>Edit</button>
              <button disabled={busy} className="text-xs uppercase tracking-wider text-red-400 hover:text-red-300" onClick={() => { if (confirm(`Delete ${n.name}? Their votes are deleted too.`)) run(() => supabase().from("nominees").delete().eq("id", n.id), "Nominee deleted"); }}>Delete</button>
            </div>
          ))}
        </div>
        <p className="mt-4 text-xs text-muted">New nominees must be added to a ballot under <b>Categories</b> before they can receive votes.</p>
      </Card>
      {f && (
        <Card title={f.id ? "Edit nominee" : "New nominee"} action={<button className="text-xs text-muted" onClick={() => setF(null)}>Close ✕</button>}>
          <div className="space-y-3">
            <div className="flex items-center gap-4"><Avatar nominee={{ name: f.name || "?", image_url: f.image_url }} className="h-20 w-20 rounded-full" textClass="text-2xl" /><input type="file" accept="image/*" onChange={onFile} className="text-xs text-muted" /></div>
            <div><label className="label">Name</label><input className="input" value={f.name} onChange={(e) => setF({ ...f, name: e.target.value, slug: f.id ? f.slug : slugify(e.target.value) })} /></div>
            <div><label className="label">URL slug</label><input className="input" value={f.slug} onChange={(e) => setF({ ...f, slug: slugify(e.target.value) })} /></div>
            <div><label className="label">Biography</label><textarea rows={3} className="input" value={f.bio} onChange={(e) => setF({ ...f, bio: e.target.value })} /></div>
            <div><label className="label">Achievements (one per line)</label><textarea rows={3} className="input" value={f.achievements} onChange={(e) => setF({ ...f, achievements: e.target.value })} /></div>
            <div><label className="label">Notable moments (one per line)</label><textarea rows={3} className="input" value={f.notable_moments} onChange={(e) => setF({ ...f, notable_moments: e.target.value })} /></div>
            <div><label className="label">Awards & nominations (one per line)</label><textarea rows={3} className="input" value={f.awards} onChange={(e) => setF({ ...f, awards: e.target.value })} /></div>
            <div><label className="label">Sort order</label><input type="number" className="input" value={f.sort_order} onChange={(e) => setF({ ...f, sort_order: Number(e.target.value) })} /></div>
            <button className="btn-gold w-full" disabled={busy || !f.name.trim()} onClick={save}>Save nominee</button>
          </div>
        </Card>
      )}
    </div>
  );
}

/* ---------------- Categories ---------------- */
function CategoriesAdmin({ categories, nominees, ballots, run, busy }: { categories: Category[]; nominees: Nominee[]; ballots: { category_id: string; nominee_id: string }[]; run: Run; busy: boolean }) {
  const [title, setTitle] = useState("");
  const [desc, setDesc] = useState("");
  const [open, setOpen] = useState<string | null>(null);
  const on = (cid: string, nid: string) => ballots.some((b) => b.category_id === cid && b.nominee_id === nid);
  const toggleBallot = (cid: string, nid: string) =>
    run(() => on(cid, nid)
      ? supabase().from("category_nominees").delete().eq("category_id", cid).eq("nominee_id", nid)
      : supabase().from("category_nominees").insert({ category_id: cid, nominee_id: nid }), "Ballot updated");
  const create = () => {
    if (!title.trim()) return;
    run(async () => {
      const { data, error } = await supabase().from("categories").insert({ title: title.trim(), description: desc, sort_order: categories.length + 1 }).select("id").single();
      if (error) throw error;
      if (nominees.length) {
        const { error: e2 } = await supabase().from("category_nominees").insert(nominees.map((n) => ({ category_id: data.id, nominee_id: n.id })));
        if (e2) throw e2;
      }
      setTitle(""); setDesc("");
    }, "Category created with all nominees on the ballot");
  };
  return (
    <div className="space-y-6">
      <Card title="Create a custom category">
        <div className="grid gap-3 md:grid-cols-[1fr_1fr_auto]">
          <input className="input" placeholder="Category title" value={title} onChange={(e) => setTitle(e.target.value)} />
          <input className="input" placeholder="Description (optional)" value={desc} onChange={(e) => setDesc(e.target.value)} />
          <button className="btn-gold" disabled={busy || !title.trim()} onClick={create}>Create</button>
        </div>
      </Card>
      <Card title="Categories & ballots">
        <div className="space-y-3">
          {categories.map((c) => (
            <div key={c.id} className="rounded-xl border border-gold/15 p-4">
              <div className="flex flex-wrap items-center gap-3">
                <p className="min-w-0 flex-1 font-serif text-xl">{c.title}{c.is_ultimate && <span className="ml-2 text-[10px] uppercase tracking-widest text-gold">Ultimate</span>}</p>
                <label className="flex items-center gap-2 text-xs text-muted"><input type="checkbox" checked={c.voting_open} onChange={() => run(() => supabase().from("categories").update({ voting_open: !c.voting_open }).eq("id", c.id), "Updated")} /> Voting open</label>
                <button className="btn-ghost !px-4 !py-2" onClick={() => setOpen(open === c.id ? null : c.id)}>Ballot ({ballots.filter((b) => b.category_id === c.id).length})</button>
                <button disabled={busy} className="text-xs uppercase tracking-wider text-muted hover:text-gold" onClick={() => { const t = prompt("Rename category", c.title); if (t?.trim()) run(() => supabase().from("categories").update({ title: t.trim() }).eq("id", c.id), "Renamed"); }}>Rename</button>
                <button disabled={busy} className="text-xs uppercase tracking-wider text-muted hover:text-red-300" onClick={() => { if (confirm("Reset votes for this category only?")) run(() => supabase().rpc("admin_reset_votes", { p_category: c.id }), "Category votes reset"); }}>Reset votes</button>
                <button disabled={busy} className="text-xs uppercase tracking-wider text-red-400" onClick={() => { if (confirm(`Delete "${c.title}" and all its votes?`)) run(() => supabase().from("categories").delete().eq("id", c.id), "Category deleted"); }}>Delete</button>
              </div>
              {open === c.id && (
                <div className="mt-4 flex flex-wrap gap-2 border-t border-gold/10 pt-4">
                  {nominees.map((n) => (
                    <button key={n.id} disabled={busy} onClick={() => toggleBallot(c.id, n.id)} className={`rounded-full border px-4 py-1.5 text-xs tracking-wider ${on(c.id, n.id) ? "border-gold bg-gold text-ink" : "border-gold/30 text-muted"}`}>{n.name}</button>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}

/* ---------------- Users ---------------- */
function UsersAdmin({ run, busy, me }: { run: Run; busy: boolean; me: string }) {
  const [users, setUsers] = useState<UserRow[] | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const load = useCallback(async () => {
    const { data, error } = await supabase().rpc("admin_user_stats");
    if (error) setErr(error.message); else setUsers(data as UserRow[]);
  }, []);
  useEffect(() => { load(); }, [load]);
  const flag = async (u: UserRow, banned: boolean, admin: boolean, ok: string) => { await run(() => supabase().rpc("admin_set_user_flags", { p_user: u.id, p_banned: banned, p_admin: admin }), ok); load(); };
  return (
    <Card title={`Users${users ? ` (${users.length})` : ""}`}>
      {err && <p className="text-sm text-red-400">{err}</p>}
      <div className="overflow-x-auto">
        <table className="w-full min-w-[560px] text-left text-sm">
          <thead className="text-[10px] uppercase tracking-[0.2em] text-muted"><tr><th className="pb-3">User</th><th>Votes</th><th>Role</th><th /></tr></thead>
          <tbody>
            {users?.map((u) => (
              <tr key={u.id} className="border-t border-gold/10">
                <td className="py-3"><p>{u.display_name}</p><p className="text-xs text-muted">{u.email}</p></td>
                <td className="tabular-nums text-champagne">{u.votes_cast}</td>
                <td>{u.is_admin ? <span className="text-gold">Admin</span> : u.is_banned ? <span className="text-red-400">Banned</span> : "Member"}</td>
                <td className="space-x-3 text-right text-xs uppercase tracking-wider">
                  {u.id !== me && <>
                    <button disabled={busy} className="text-muted hover:text-red-300" onClick={() => flag(u, !u.is_banned, u.is_admin, u.is_banned ? "Unbanned" : "Banned")}>{u.is_banned ? "Unban" : "Ban"}</button>
                    <button disabled={busy} className="text-muted hover:text-gold" onClick={() => flag(u, u.is_banned, !u.is_admin, u.is_admin ? "Admin removed" : "Admin granted")}>{u.is_admin ? "Remove admin" : "Make admin"}</button>
                  </>}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Card>
  );
}

/* ---------------- Gallery & Hall of Fame ---------------- */
function MediaAdmin({ gallery, hall, year, run, flash, busy }: { gallery: { id: string; image_url: string; caption: string | null }[]; hall: { id: string; edition_year: number; category_title: string; winner_name: string }[]; year: number; run: Run; flash: (t: "ok" | "err", s: string) => void; busy: boolean }) {
  const [caption, setCaption] = useState("");
  const [h, setH] = useState({ edition_year: year - 1, category_title: "", winner_name: "", note: "" });
  const onFile = async (e: ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files ?? []); if (!files.length) return;
    await run(async () => {
      for (const file of files) {
        const url = await upload("gallery", file);
        const { error } = await supabase().from("gallery").insert({ image_url: url, caption });
        if (error) throw error;
      }
      setCaption("");
    }, `${files.length} photo(s) added`);
    e.target.value = "";
  };
  void flash;
  return (
    <div className="grid gap-6 lg:grid-cols-2">
      <Card title="Gallery">
        <div className="mb-4 space-y-3">
          <input className="input" placeholder="Caption for the next upload (optional)" value={caption} onChange={(e) => setCaption(e.target.value)} />
          <input type="file" accept="image/*" multiple onChange={onFile} className="text-xs text-muted" disabled={busy} />
        </div>
        <div className="grid grid-cols-3 gap-2">
          {gallery.map((g) => (
            <div key={g.id} className="group relative aspect-square overflow-hidden rounded-lg border border-gold/20">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={g.image_url} alt="" className="h-full w-full object-cover" />
              <button onClick={() => { if (confirm("Delete this photo?")) run(() => supabase().from("gallery").delete().eq("id", g.id), "Photo deleted"); }} className="absolute inset-0 bg-black/70 text-xs uppercase tracking-wider text-red-300 opacity-0 transition-opacity group-hover:opacity-100">Delete</button>
            </div>
          ))}
        </div>
      </Card>
      <Card title="Hall of Fame (past winners)">
        <div className="mb-5 grid gap-3">
          <div className="grid grid-cols-[100px_1fr] gap-3"><input type="number" className="input" value={h.edition_year} onChange={(e) => setH({ ...h, edition_year: Number(e.target.value) })} /><input className="input" placeholder="Category" value={h.category_title} onChange={(e) => setH({ ...h, category_title: e.target.value })} /></div>
          <input className="input" placeholder="Winner" value={h.winner_name} onChange={(e) => setH({ ...h, winner_name: e.target.value })} />
          <input className="input" placeholder="Note (optional)" value={h.note} onChange={(e) => setH({ ...h, note: e.target.value })} />
          <button className="btn-gold" disabled={busy || !h.category_title.trim() || !h.winner_name.trim()} onClick={() => run(async () => { const { error } = await supabase().from("hall_of_fame").insert(h); if (error) throw error; setH({ ...h, category_title: "", winner_name: "", note: "" }); }, "Added to Hall of Fame")}>Add entry</button>
        </div>
        <ul className="space-y-2 text-sm">
          {hall.map((e) => (
            <li key={e.id} className="flex items-center justify-between border-t border-gold/10 pt-2"><span>{e.edition_year} · {e.category_title} — <span className="text-champagne">{e.winner_name}</span></span><button className="text-xs text-red-400" onClick={() => run(() => supabase().from("hall_of_fame").delete().eq("id", e.id), "Removed")}>Remove</button></li>
          ))}
        </ul>
      </Card>
    </div>
  );
}
