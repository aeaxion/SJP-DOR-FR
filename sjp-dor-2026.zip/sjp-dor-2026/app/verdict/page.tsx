"use client";
import { useEffect, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import Avatar from "@/components/Avatar";
import WinnerReveal from "@/components/WinnerReveal";
import { useStore } from "@/lib/store";

export default function Verdict() {
  const { categories, tally } = useStore();
  const [playing, setPlaying] = useState<string | null>(null);
  const seen = useRef<Set<string> | null>(null);

  // When the admin reveals an award while this page is open, auto-play the ceremony.
  useEffect(() => {
    const revealed = new Set(categories.filter((c) => c.revealed).map((c) => c.id));
    if (seen.current === null) { seen.current = revealed; return; }
    for (const id of revealed) {
      if (!seen.current.has(id)) { setPlaying(id); break; }
    }
    seen.current = revealed;
  }, [categories]);

  const ordered = [...categories].sort((a, b) => Number(a.is_ultimate) - Number(b.is_ultimate)); // ultimate last
  const playCat = categories.find((c) => c.id === playing);

  return (
    <div className="mx-auto max-w-6xl px-5 py-16">
      <div className="mb-14 text-center">
        <p className="eyebrow mb-3">The Ceremony</p>
        <h1 className="font-serif text-5xl gold-text md:text-8xl">THE FINAL VERDICT</h1>
        <p className="mx-auto mt-5 max-w-lg text-muted">Winners are unveiled one at a time. Keep this page open — when an award is revealed, the ceremony begins.</p>
      </div>

      <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">
        {ordered.map((c) => {
          const rows = c.revealed ? tally(c.id) : [];
          const w = rows[0];
          return (
            <motion.div key={c.id} layout className={`glass relative overflow-hidden p-6 ${c.is_ultimate ? "md:col-span-2 lg:col-span-3 !border-gold shadow-gold" : ""}`}>
              <p className="text-[10px] uppercase tracking-[0.3em] text-gold">{c.is_ultimate ? "The Ultimate Award" : "Award"}</p>
              <h2 className={`mt-2 font-serif gold-text ${c.is_ultimate ? "text-4xl" : "text-2xl"}`}>{c.title}</h2>
              {c.revealed && w ? (
                <div className="mt-6 flex items-center gap-4">
                  <Avatar nominee={w.nominee} className={`${c.is_ultimate ? "h-24 w-24" : "h-16 w-16"} shrink-0 rounded-full border-2 border-champagne`} textClass="text-2xl" />
                  <div className="min-w-0 flex-1">
                    <p className={`truncate font-serif tracking-[0.12em] ${c.is_ultimate ? "text-5xl" : "text-3xl"}`}>{w.nominee.name}</p>
                    <p className="text-xs text-muted">{w.votes} votes · {w.pct.toFixed(1)}%</p>
                  </div>
                  <button onClick={() => setPlaying(c.id)} className="btn-ghost !px-4 !py-2">Replay</button>
                </div>
              ) : (
                <div className="mt-6 flex items-center gap-3 text-muted">
                  <span className="flex h-12 w-12 items-center justify-center rounded-full border border-dashed border-gold/40 text-gold">?</span>
                  <span className="text-xs uppercase tracking-[0.25em]">Sealed</span>
                </div>
              )}
            </motion.div>
          );
        })}
      </div>

      <AnimatePresence>
        {playCat && <WinnerReveal key={playCat.id} category={playCat} rows={tally(playCat.id)} onClose={() => setPlaying(null)} />}
      </AnimatePresence>
    </div>
  );
}
