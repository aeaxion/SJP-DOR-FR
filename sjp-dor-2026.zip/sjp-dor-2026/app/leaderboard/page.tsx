"use client";
import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import Avatar from "@/components/Avatar";
import ShareButton from "@/components/ShareButton";
import { useStore } from "@/lib/store";

const podium = {
  1: { h: "h-56 md:h-72", bar: "bg-gold-gradient", label: "text-ink", ring: "border-champagne shadow-gold-lg", size: "h-28 w-28 md:h-36 md:w-36" },
  2: { h: "h-40 md:h-52", bar: "bg-gradient-to-b from-[#e8e8e8] via-[#b4b4b4] to-[#6e6e6e]", label: "text-ink", ring: "border-[#cfcfcf]", size: "h-20 w-20 md:h-28 md:w-28" },
  3: { h: "h-32 md:h-40", bar: "bg-gradient-to-b from-[#e0a46a] via-[#b87333] to-[#6b3f16]", label: "text-ink", ring: "border-[#b87333]", size: "h-20 w-20 md:h-28 md:w-28" },
} as const;

export default function Leaderboard() {
  const { categories, tally, total, resultsVisible } = useStore();
  const [id, setId] = useState<string | null>(null);
  useEffect(() => { if (!id && categories.length) setId(categories[0].id); }, [categories, id]);
  const cat = categories.find((c) => c.id === id);
  const visible = cat ? resultsVisible(cat) : false;
  const rows = cat ? tally(cat.id) : [];
  const t = cat ? total(cat.id) : 0;
  const top = rows.slice(0, 3);
  // Visual order: 2nd, 1st, 3rd
  const order = [top[1], top[0], top[2]].filter(Boolean);

  return (
    <div className="mx-auto max-w-5xl px-5 py-16">
      <div className="mb-10 text-center">
        <p className="eyebrow mb-3">The Standings</p>
        <h1 className="section-title">Leaderboard</h1>
      </div>
      <div className="mb-10 flex flex-wrap justify-center gap-2">
        {categories.map((c) => (
          <button key={c.id} onClick={() => setId(c.id)}
            className={`rounded-full border px-4 py-2 text-[11px] uppercase tracking-[0.15em] transition-all ${id === c.id ? "border-gold bg-gold text-ink" : "border-gold/30 text-muted hover:border-gold hover:text-champagne"}`}>
            {c.is_ultimate ? "Ultimate" : c.title}
          </button>
        ))}
      </div>

      {cat && !visible && <div className="glass p-12 text-center"><p className="font-serif text-2xl gold-text">The standings are sealed</p><p className="mt-2 text-sm text-muted">Check back once voting closes.</p></div>}

      {cat && visible && (
        <>
          <h2 className="mb-10 text-center font-serif text-3xl gold-text">{cat.title}</h2>
          <div className="mb-12 flex items-end justify-center gap-3 md:gap-6">
            {order.map((r) => {
              const p = podium[r.rank as 1 | 2 | 3];
              return (
                <motion.div layout key={r.nominee.id} transition={{ type: "spring", stiffness: 200, damping: 26 }} className="flex w-1/3 max-w-[220px] flex-col items-center">
                  <Avatar nominee={r.nominee} className={`${p.size} rounded-full border-4 ${p.ring}`} textClass="text-3xl" />
                  <p className="mt-3 font-serif text-lg tracking-[0.1em] md:text-2xl">{r.nominee.name}</p>
                  <p className="mb-3 text-xs text-muted">{r.votes} votes · {r.pct.toFixed(0)}%</p>
                  <motion.div initial={{ height: 0 }} animate={{ height: "auto" }} className={`${p.h} flex w-full items-start justify-center rounded-t-xl pt-3 ${p.bar}`}>
                    <span className={`font-serif text-5xl font-bold md:text-7xl ${p.label}`}>{r.rank}</span>
                  </motion.div>
                </motion.div>
              );
            })}
          </div>
          <div className="space-y-3">
            {rows.slice(3).map((r) => (
              <motion.div layout key={r.nominee.id} className="glass flex items-center gap-4 p-4">
                <span className="w-8 text-center font-serif text-3xl text-muted">{r.rank}</span>
                <Avatar nominee={r.nominee} className="h-12 w-12 rounded-full border border-gold/30" textClass="text-base" />
                <span className="flex-1 font-serif text-xl tracking-[0.1em]">{r.nominee.name}</span>
                <span className="text-sm tabular-nums text-muted"><span className="text-champagne">{r.votes}</span> · {r.pct.toFixed(1)}%</span>
              </motion.div>
            ))}
          </div>
          <div className="mt-10 flex items-center justify-between">
            <p className="text-xs uppercase tracking-[0.25em] text-muted">Total votes: <span className="text-champagne">{t}</span></p>
            <ShareButton text={`SJP DOR 2026 — ${cat.title}: ${rows.slice(0, 3).map((r) => `${r.rank}. ${r.nominee.name}`).join(" ")}`} label="Share leaderboard" />
          </div>
        </>
      )}
    </div>
  );
}
