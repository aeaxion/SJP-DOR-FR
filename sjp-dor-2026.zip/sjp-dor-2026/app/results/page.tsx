"use client";
import { useEffect, useState } from "react";
import ResultsBoard from "@/components/ResultsBoard";
import { useStore } from "@/lib/store";

export default function Results() {
  const { categories, total, resultsVisible } = useStore();
  const [id, setId] = useState<string | null>(null);
  useEffect(() => { if (!id && categories.length) setId(categories[0].id); }, [categories, id]);
  const cat = categories.find((c) => c.id === id);
  const grand = categories.reduce((a, c) => a + (resultsVisible(c) ? total(c.id) : 0), 0);

  return (
    <div className="mx-auto max-w-5xl px-5 py-16">
      <div className="mb-10 text-center">
        <p className="eyebrow mb-3">Live Results</p>
        <h1 className="section-title">The Count</h1>
        <p className="mt-4 text-sm text-muted">Votes across visible categories: <span className="text-champagne">{grand}</span></p>
      </div>
      <div className="mb-8 flex flex-wrap justify-center gap-2">
        {categories.map((c) => (
          <button key={c.id} onClick={() => setId(c.id)}
            className={`rounded-full border px-4 py-2 text-[11px] uppercase tracking-[0.15em] transition-all ${id === c.id ? "border-gold bg-gold text-ink" : "border-gold/30 text-muted hover:border-gold hover:text-champagne"}`}>
            {c.is_ultimate ? "Ultimate" : c.title}
          </button>
        ))}
      </div>
      {cat && (
        <>
          <h2 className="mb-6 text-center font-serif text-3xl gold-text">{cat.title}</h2>
          <ResultsBoard category={cat} />
        </>
      )}
    </div>
  );
}
