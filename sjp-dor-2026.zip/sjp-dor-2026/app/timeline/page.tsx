"use client";
import { motion } from "framer-motion";
import { useStore } from "@/lib/store";

const fmt = (d: string | null | undefined) => d ? new Date(d).toLocaleString(undefined, { dateStyle: "full", timeStyle: "short" }) : "Date to be announced";

export default function Timeline() {
  const { settings: s } = useStore();
  const items = [
    ["Nominations announced", s?.nominations_date],
    ["Voting begins", s?.voting_start_date],
    ["Voting closes", s?.voting_end_date],
    ["The awards ceremony", s?.event_date],
    ["Winner announcement", s?.announcement_date ?? s?.event_date],
  ] as const;
  const now = Date.now();
  return (
    <div className="mx-auto max-w-3xl px-5 py-16">
      <div className="mb-14 text-center">
        <p className="eyebrow mb-3">The road to glory</p>
        <h1 className="section-title">Event Timeline</h1>
      </div>
      <div className="relative border-l border-gold/30 pl-8">
        {items.map(([label, date], i) => {
          const past = date ? new Date(date).getTime() < now : false;
          return (
            <motion.div key={label} initial={{ opacity: 0, x: -20 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.08 }} className="relative mb-10">
              <span className={`absolute -left-[41px] top-1.5 h-4 w-4 rotate-45 border border-gold ${past ? "bg-gold" : "bg-ink"}`} />
              <p className="text-[10px] uppercase tracking-[0.3em] text-gold">Step {i + 1}{past ? " · Complete" : ""}</p>
              <h2 className="font-serif text-3xl gold-text">{label}</h2>
              <p className="mt-1 text-sm text-muted">{fmt(date)}</p>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}
