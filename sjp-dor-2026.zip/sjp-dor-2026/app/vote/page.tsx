"use client";
import Link from "next/link";
import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import Avatar from "@/components/Avatar";
import Particles from "@/components/Particles";
import { supabase } from "@/lib/supabase";
import { useStore } from "@/lib/store";

export default function Vote() {
  const { user, settings, categories, nomineesFor, myVotes, refresh, nominees } = useStore();
  const [activeId, setActiveId] = useState<string | null>(null);
  const [selected, setSelected] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [done, setDone] = useState<{ nomineeId: string; changed: boolean } | null>(null);

  const active = categories.find((c) => c.id === activeId) ?? null;
  const open = !!settings?.voting_open;

  useEffect(() => { setSelected(null); setError(null); setDone(null); }, [activeId]);

  const confirm = async () => {
    if (!active || !selected) return;
    setBusy(true); setError(null);
    const { data, error } = await supabase().rpc("cast_vote", { p_category: active.id, p_nominee: selected });
    setBusy(false);
    if (error) { setError(error.message); return; }
    setDone({ nomineeId: selected, changed: (data as { status: string })?.status === "changed" });
    refresh();
  };

  // ---------- Category picker ----------
  if (!active) {
    return (
      <div className="mx-auto max-w-6xl px-5 py-16">
        <div className="mb-12 text-center">
          <p className="eyebrow mb-3">The Voting Hall</p>
          <h1 className="section-title">Choose an Award</h1>
          <p className="mx-auto mt-4 max-w-xl text-muted">One vote per category. {settings?.allow_vote_change ? "You may change your vote while voting is open." : "Votes are final once confirmed."}</p>
          {!open && <p className="mx-auto mt-6 max-w-md rounded-full border border-gold/40 bg-gold/10 px-5 py-2 text-xs uppercase tracking-[0.2em] text-champagne">Voting is currently closed</p>}
          {!user && open && <Link href="/login" className="btn-gold mt-6">Sign in to vote</Link>}
        </div>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {categories.map((c, i) => {
            const voted = myVotes[c.id];
            const votedFor = nominees.find((n) => n.id === voted);
            const locked = !open || !c.voting_open || c.revealed;
            return (
              <motion.button key={c.id} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.04 }}
                onClick={() => setActiveId(c.id)}
                className={`group glass relative p-6 text-left transition-all duration-300 hover:-translate-y-1 hover:border-champagne hover:shadow-gold ${c.is_ultimate ? "md:col-span-2 lg:col-span-3 !border-gold/60 bg-gold/5" : ""}`}>
                <div className="mb-3 flex items-center justify-between">
                  <span className="text-[10px] uppercase tracking-[0.3em] text-gold">{c.is_ultimate ? "The Ultimate Award" : `Award ${String(i + 1).padStart(2, "0")}`}</span>
                  {voted ? <span className="rounded-full bg-gold px-2.5 py-0.5 text-[10px] font-bold uppercase tracking-wider text-ink">Voted ✓</span>
                    : locked ? <span className="text-[10px] uppercase tracking-wider text-muted">{c.revealed ? "Revealed" : "Closed"}</span> : null}
                </div>
                <h2 className={`font-serif gold-text ${c.is_ultimate ? "text-4xl" : "text-2xl"}`}>{c.title}</h2>
                {votedFor && <p className="mt-3 text-xs text-muted">Your pick: <span className="text-champagne">{votedFor.name}</span></p>}
              </motion.button>
            );
          })}
        </div>
      </div>
    );
  }

  const ballot = nomineesFor(active.id);
  const voted = myVotes[active.id];
  const locked = !open || !active.voting_open || active.revealed;
  const canVote = !!user && !locked && (!voted || !!settings?.allow_vote_change);

  return (
    <div className="mx-auto max-w-6xl px-5 py-14">
      <button onClick={() => setActiveId(null)} className="text-[11px] uppercase tracking-[0.3em] text-muted hover:text-gold">← All awards</button>
      <div className="mb-12 mt-6 text-center">
        <p className="eyebrow mb-3">{active.is_ultimate ? "The Ultimate Award" : "Award"}</p>
        <h1 className="section-title">{active.title}</h1>
      </div>

      {!user && <p className="mb-8 text-center text-sm text-champagne">You need to <Link href="/login" className="underline">sign in</Link> to vote.</p>}
      {user && locked && <p className="mb-8 text-center text-sm text-champagne">Voting is closed for this award.</p>}
      {user && !locked && voted && !settings?.allow_vote_change && <p className="mb-8 text-center text-sm text-champagne">You’ve already voted in this category. Votes are final.</p>}
      {user && !locked && voted && settings?.allow_vote_change && <p className="mb-8 text-center text-sm text-champagne">You’ve voted. You can change your pick below.</p>}

      <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-5">
        {ballot.map((n) => {
          const isSel = selected === n.id;
          const isMine = voted === n.id;
          return (
            <button key={n.id} disabled={!canVote} onClick={() => setSelected(n.id)}
              className={`group relative overflow-hidden rounded-2xl border bg-charcoal text-center transition-all duration-300 ${isSel ? "-translate-y-2 border-champagne shadow-gold-lg" : isMine ? "border-gold/70" : "border-gold/25"} ${canVote ? "hover:-translate-y-1 hover:border-gold" : "cursor-default opacity-90"}`}>
              <Avatar nominee={n} className="aspect-[4/5] w-full" textClass="text-6xl" />
              {isSel && <div className="absolute right-3 top-3 flex h-8 w-8 items-center justify-center rounded-full bg-gold text-ink">✓</div>}
              {isMine && !isSel && <div className="absolute right-3 top-3 rounded-full bg-ink/80 px-2 py-1 text-[9px] uppercase tracking-wider text-gold">Your vote</div>}
              <div className="p-4"><p className="font-serif text-2xl tracking-[0.12em] gold-text">{n.name}</p></div>
            </button>
          );
        })}
      </div>

      {error && <p className="mt-8 text-center text-sm text-red-400">{error}</p>}

      {canVote && (
        <div className="mt-12 text-center">
          <button className="btn-gold !px-12 !py-4" disabled={!selected || busy || selected === voted} onClick={confirm}>
            {busy ? "Casting…" : voted ? "Change your vote" : "Confirm your vote"}
          </button>
          {!selected && <p className="mt-3 text-xs text-muted">Select a nominee first.</p>}
        </div>
      )}

      {/* Confirmation screen */}
      <AnimatePresence>
        {done && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-50 flex items-center justify-center bg-ink/95 px-5">
            <Particles burst count={50} />
            <div className="relative text-center">
              <svg viewBox="0 0 120 120" className="mx-auto h-36 w-36">
                <motion.circle cx="60" cy="60" r="52" fill="none" stroke="#D4AF37" strokeWidth="3" initial={{ pathLength: 0 }} animate={{ pathLength: 1 }} transition={{ duration: 0.9 }} />
                <motion.path d="M34 62 L53 80 L88 42" fill="none" stroke="#F5D76E" strokeWidth="6" strokeLinecap="round" strokeLinejoin="round" initial={{ pathLength: 0 }} animate={{ pathLength: 1 }} transition={{ delay: 0.8, duration: 0.6 }} />
              </svg>
              <motion.h2 initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 1.3 }} className="mt-8 font-serif text-4xl gold-text md:text-6xl">
                {done.changed ? "YOUR VOTE HAS BEEN CHANGED." : "YOUR VOTE HAS BEEN CAST."}
              </motion.h2>
              <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 1.6 }} className="mt-4 text-muted">
                {active.title} · <span className="text-champagne">{nominees.find((n) => n.id === done.nomineeId)?.name}</span>
              </motion.p>
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 1.9 }} className="mt-10 flex flex-col justify-center gap-3 sm:flex-row">
                <button className="btn-gold" onClick={() => { setDone(null); setActiveId(null); }}>Vote in another category</button>
                <Link href="/results" className="btn-ghost">View results</Link>
              </motion.div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
